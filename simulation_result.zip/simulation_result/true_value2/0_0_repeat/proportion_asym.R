a1 <- read.csv("/Users/timtsang/Dropbox/kiddivax_transmission/asymptomatic/program_rcpp/v1_1/proportion_no_inf.csv")

a2 <- read.csv("/Users/timtsang/Dropbox/kiddivax_transmission/asymptomatic/program_rcpp/v1_1/proportion_normal.csv")

ttt <- (a2-a1)/a2

para_summary(ttt,4,3,1)