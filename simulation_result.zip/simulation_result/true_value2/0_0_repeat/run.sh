#!/bin/bash
#SBATCH --job-name=TND
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=8gb
#SBATCH --time=70:00:00
#SBATCH --account=epi
#SBATCH --qos=epi
#SBATCH --partition=hpg2-compute
pwd; hostname; date

cat /proc/cpuinfo

module load R

Rscript transmission.r

date
