## add misclassification in estimation


rm(list = ls())
print('akfhjajksfhjsk')
library(Rcpp)
library(RcppParallel)

Sys.setenv("PKG_CXXFLAGS"="-std=c++11")
########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
    y[i,1] <- mean(mcmc[,i])
    }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}

para_summary2 <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),5)
  for (i in 1:ncol(mcmc)){
    y[i,1:5] <- quantile(mcmc[,i],c(0.5,0.025,0.975,0.05,0.95))
    y[i,1] <- mean(mcmc[,i])
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}

try(setwd("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/simulation_re/true_value2/0_0_repeat"))
try(setwd("Z:/kiddivax_transmission/asymptomatic/simulation/value6"))
try(setwd("C:/Users/user/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/simulation_re/true_value2/0_0_repeat"))

for (iiii in 1:50){
########################################################################################################################################################################
data <- read.csv("2022_10_22_data_v1_ari.csv")
data[is.na(data)] <- -1
sym <- read.csv("2022_10_22_sym_v1_ari.csv")

                     
########################################################################################################################################################################

ILI <- read.csv("ILILAB_2019_04_25.csv",header=F)
ILI[ILI==0] <- 0.00000000001

## here also adjust the 14 day delay here
## here the proxy is starting from 2008/01/01, data is starting from 2008/07/01
ILI <- ILI[-c(1:(182-14)),]


## for parameter of SI
## assumed to be known and put in the code directly

## model parameter
## 1,2,3,4, the probability of symptom: h1, children and adults and h3, children and adults 
## 5-11: season 1-6
## 12-17: household transmission parameter for 6 season (can use 12,13 for h1 and h3 first)
## 18-19,20-21,22-23,24-25,26-27,28-29, age parameter for children and older adults.
## 30-33, transmissiliby for asymptomatic vs symptomatic: h1, children and adults, h3 children and adults (30,31, children , adults ).
## 34-39, HAI titer protection

### later add (those variance parameter)

## first create a function for simulation

int_para <-  c(rep(0.6,4),
               rep(0.1,7),
               rep(0.05,6),
               rep(c(0,0),6),
               rep(0,4),
               rep(0,6))


# children, adults
int_para2 <- c(0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005) 

int_para <- as.vector(as.matrix(read.csv("para1.csv"))[,2] )
int_para2 <- as.vector(as.matrix(read.csv("para2.csv"))[,2])
for (i in 1:12){
int_para2[10*(i-1)+1] <- 1- sum(int_para2[10*(i-1)+2:10])
}
#int_para[30] <- log(0.4)


sourceCpp("transmission.cpp")

########################################################################################################################################################################
########### here is inputing the data
data <- as.matrix(data)
sym <- as.matrix(sym)
ILI <- as.matrix(ILI)
########################################################################################################################################################################

sum(data[,8]==0&data[,6]==1)
sym[data[,8]==0&data[,6]==1,1:2]

### in MCMC, need to chnage the level for para 34,35!!!!!!!!!!
# 1. sym -> asym, 2. asym -> sym
mis_class <- c(0,0)

t <- sim_data(data,sym,ILI,int_para,int_para2,c(1,1,1),0.25,mis_class)

input1 <- t[[1]]
input2 <- t[[2]]
input1_full <- t[[3]]

table(data[,6+0:7*5]==-1)
table(input1[,6+0:7*5]==-1)
#input1[t[[4]][,1]==101,] -> bb
########################################################################################################################################################################
## here to set to real data
#input1 <- data
#input2 <- sym

########################################################################################################################################################################

SI <- serial_density(4.98,3.49)

########################################################################################################################################################################
## here is the testing session

# 


test <- loglik(input1_full,input1,ILI,int_para,int_para2,SI,1,1,1)
sum(test[[1]])+sum(test[[2]])+sum(test[[3]])

 sourceCpp("transmission.cpp")
 
 test2 <- all_update(input1_full,input1,input2,ILI,int_para,int_para2,SI,0,test[[1]],test[[2]],test[[3]])
 sum(test2[[2]])+sum(test2[[3]])+sum(test2[[4]])
 
 test3 <- loglik(test2[[1]],input1,ILI,int_para,int_para2,SI,1,1,1)
 sum(test3[[1]])+sum(test3[[2]])+sum(test3[[3]])

 sourceCpp("transmission.cpp")
 
 test <- loglik(input1_full,input1,ILI,int_para,int_para2,SI,1,1,1)
 sum(test[[1]])+sum(test[[2]])+sum(test[[3]])
 
 test2 <- add_remove_infection(input1_full,input1,input2,ILI,int_para,int_para2,SI,test[[1]],test[[2]],test[[3]])
 sum(test2[[2]])+sum(test2[[3]])+sum(test2[[4]])
 
 test3 <- loglik(test2[[1]],input1,ILI,int_para,int_para2,SI,1,1,1)
 sum(test3[[1]])+sum(test3[[2]])+sum(test3[[3]])

####################################################################################

sigma <- (abs(int_para)+0.1)/10
move <- rep(1,length(int_para))
move[c(3:4,7:11,13:17,19:29,31:39)] <- 0
para <- int_para
#move[5:39] <- 0

int_para3 <- rep(1,12)
sigma3 <- int_para3/10

para2 <- rep(0.1,120)


sourceCpp("transmission.cpp")

aaaaa1 <- Sys.time()
tt <- mcmc(input1,input2,ILI,100000,para,para2,int_para3,move,sigma,sigma3)
aaaaa2 <- Sys.time()
print(aaaaa2-aaaaa1)

#para_summary(tt[[2]],4,3,1)

#table(floor(tt[[8]][t[[2]][,9]!=-1&t[[1]][,3]<1,9]))/sum(table(floor(tt[[8]][t[[2]][,9]!=-1&t[[1]][,3]<1,9])))

#table(floor(tt[[8]][t[[1]][,3]<1,9]))/sum(table(floor(tt[[8]][t[[1]][,3]<1,9])))




id <- runif(1,0,1)
inc <- 50000+1:10000*5
z1 <- para_summary2((tt[[1]][inc,]),4,4,1)
write.csv(z1,paste("mcmc_summary_",id,".csv",sep=""))

z2 <- para_summary((tt[[2]][inc,]),4,4,1)
#write.csv(z2,paste("mcmc_summary2_",id,".csv",sep=""))

z3 <- para_summary((tt[[3]][inc,]),4,4,1)
}

# 
# save.image(paste("image_",id,".Rdata",sep=""))
# 
# 
# 
# 
# asdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdg
# 
# 
# 
# #### DIC and household size distribution
# ## 0-8
# housesizedist <- list(matrix(0,10000,81),matrix(0,10000,81),matrix(0,10000,81),matrix(0,10000,81),matrix(0,10000,81),matrix(0,10000,81),matrix(0,10000,81))
# housesizedistdata <- matrix(0,7,81)
# 
# for (i in 1:10000){
#   
#   inputpara <- tt[[1]][50000+5*i,]
#   inputpara2 <- tt[[2]][50000+5*i,]
#   t <- sim_data(data,sym,ILI,inputpara,inputpara2)
#   data1 <- t[[1]]
#   
#   houseinfn <- rowSums( data1[,1:8*5+1]==1)
#   
#   
#   for (k in 2:8){
#     for (j in 0:8){
#       housesizedist[[1]][i,9*k+j+1] <- sum(houseinfn[data[,2]==k]==j)  
#       for (l in 0:5){
#         housesizedist[[2+l]][i,9*k+j+1] <- sum(houseinfn[data[,2]==k&data[,46]==l]==j)  
#       }
#     }
#   }
#   
# }
# 
# 
# 
# houseinfn <- rowSums( data[,1:8*5+1]==1)
# for (k in 2:8){
#   for (j in 0:8){
#     housesizedistdata[1,9*k+j+1] <- sum(houseinfn[data[,2]==k]==j)  
#     for (l in 0:5){
#       housesizedistdata[2+l,9*k+j+1] <- sum(houseinfn[data[,2]==k&data[,46]==l]==j)  
#     }
#   }
# }
# 
# 
# uu <- 1
# z1 <- para_summary(housesizedist[[uu]],4,3,0)
# z1[,4] <- housesizedistdata[uu,] 
# 
# write.csv(z1,paste("householdsizedist_",id,".csv",sep=""))
