
link <- "/Users/timtsang/Dropbox/kiddivax_transmission/program_rcpp/v1_1/"

## set path
setwd(link)

## read the zika.r files

a1 <- readLines(paste(link,"DIC.R",sep=""))
a3 <- readLines(paste(link,"runb_DIC.sh",sep=""))

command <- rep("",100)

for (b1 in 1:100){
       
        a11 <- a1
       a11[35] <- paste("for (id in ",(b1-1)*10+1,":",b1*10,"){",sep="")
        writeLines(a11,paste(  "DIC_",b1,".R",sep=""))  
     a31 <- a3
        a31[17] <- paste("Rscript DIC_",b1,".R",sep="")
        writeLines(a31,paste(  "run_",b1,".sh",sep="")) 
        command[b1] <- paste(  "sbatch run_",b1,".sh",sep="")
        
        

}




writeLines(command,"command1.txt")  
