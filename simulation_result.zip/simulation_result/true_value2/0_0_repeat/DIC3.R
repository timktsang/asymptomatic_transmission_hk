
rm(list = ls())

library(Rcpp)
library(RcppParallel)


########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}
setwd("/Users/timtsang/Dropbox/kiddivax_transmission/asymptomatic/program_rcpp/v1_1")
setwd("Z:/kiddivax_transmission/asymptomatic/program_rcpp/v1_1")

load("image_0.105974006699398.Rdata")
sourceCpp("transmission.cpp")
## DIC
inc <- 50000+1:1000*5
inputparam1 <- rbind(colMeans(tt[[1]][inc,]),tt[[1]][inc,])
inputparam2 <- rbind(colMeans(tt[[2]][inc,]),tt[[2]][inc,])
outbb <- matrix(NA,10000,7)
for (id in 1:10000){
print(id)
inputpara1 <- inputparam1[id,]
inputpara2 <- inputparam2[id,]
inputpara1[30] <- -10
inputpara1[12:17] <- 0.0000000001
aaaaa1 <- Sys.time()
bb <- countmatch(data,sym,ILI,inputpara1,inputpara2,200)
aaaaa2 <- Sys.time()
print(aaaaa2-aaaaa1)

outbb[id,] <- colSums(bb)/200
}

write.csv(outbb,"proportion_no_hh.csv",row.names = F)

