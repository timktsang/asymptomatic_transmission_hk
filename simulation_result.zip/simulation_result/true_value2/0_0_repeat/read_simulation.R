
setwd("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/simulation_misclassification/0.2_0.2")


rawlist <- list.files(pattern="*.csv")
rawlist1 <- rawlist[grepl("summary_",rawlist)]
rawlist2 <- rawlist[grepl("summary2_",rawlist)]

int_para <-  c(rep(0.6,4),
               rep(0.1,7),
               rep(0.05,6),
               rep(c(0.5,-0.5),6),
               rep(-0.5,4),rep(0.5,2))



# children, adults
int_para2 <- c(0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005) 

int_para <- as.vector(as.matrix(read.csv("para1.csv"))[,2] )
int_para2 <- as.vector(as.matrix(read.csv("para2.csv"))[,2])
for (i in 1:12){
  int_para2[10*(i-1)+1] <- 1- sum(int_para2[10*(i-1)+2:10])
}
#int_para[34] <- 0
#int_para[35:39] <- -0.2
int_para[30] <- log(0.25)

nsim <- length(rawlist1)
tt1 <- tt2 <- matrix(NA,nsim,length(int_para))
tt1 <- tt2 <- matrix(NA,nsim,length(int_para))
tt12 <- tt22 <- matrix(NA,nsim,length(int_para2))

CI_asym <- rep(0,nsim)

for (i in 1:nsim){
temp <- read.csv(rawlist1[i])  
tt1[i,] <- temp[,2]
tt2[i,] <- 1*(temp[,3] <= int_para & temp[,4] >= int_para)

CI_asym[i] <- temp[30,4]

temp <- read.csv(rawlist2[i])  
tt12[i,] <- temp[,2]
tt22[i,] <- 1*(temp[,3] <= int_para2 & temp[,4] >= int_para2)
}

summary(tt1)
summary(tt2)

summary(tt12)
summary(tt22)

## also compute the CI
CI_asym 
mean(CI_asym <0)


test <- read.csv("/Users/timtsang/Dropbox2/Dropbox/kiddivax/multiple_strain/program_rcpp/simulation2/mcmc_result_0.0584603897295892.csv")



########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}

para_summary(test[50000+5*1:10000,2:ncol(test)],4,3,1)