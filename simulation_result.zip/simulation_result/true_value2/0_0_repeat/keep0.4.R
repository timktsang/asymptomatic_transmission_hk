v1 full
v2 no asym
v3 subtype spec asym prob
v4 age + subtype spec asym prob
v5 age subtype specific 
v6 hai subtype specific
v7 communtiy risk subtype specific
v8 household risk subtype specific