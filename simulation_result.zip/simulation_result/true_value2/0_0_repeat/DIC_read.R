
rm(list = ls())

library(Rcpp)
library(RcppParallel)


########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}
setwd("/Users/timtsang/Dropbox/kiddivax_transmission/program_rcpp/v2_2")
#setwd("Z:/kiddivax_transmission/program_rcpp/v2")

LL <- matrix(NA,1000,1)
for (i in 1:100){
temp <- read.csv(paste("match_",i*10,".csv",sep=""))  
LL[(i-1)*10+1:10,1] <- temp[(i-1)*10+1:10,1]
}

DIC <- 2*LL[1]-4*mean(LL[2:1000])
write.csv(DIC,"DIC.csv",row.names = F)