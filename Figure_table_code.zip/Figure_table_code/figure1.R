setwd("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload")

########
kiddivax_asy <- read.csv('data/2022_10_24_result_ari.csv')
sensitivity <- read.csv('data/2022_10_24_result_any.csv')

rownames <- c('Children','Adults')
#rowname2 <- rep(c("H1N1","H3N2"),3)
rownames3 <- paste0(format(round(kiddivax_asy[c(3,7),3],3)*100,nsmall = 1),' (',format(round(kiddivax_asy[c(3,7),4],3)*100,nsmall = 1),
                    ', ',format(round(kiddivax_asy[c(3,7),5],2)*100,nsmall = 1),')')
rownames4 <- paste0(format(round(sensitivity[c(3,7),3],3)*100,nsmall = 1),' (',format(round(sensitivity[c(3,7),4],3)*100,nsmall = 1),
                    ', ',format(round(sensitivity[c(3,7),5],2)*100,nsmall = 1),')')
rownames5 <- paste0(format(round(kiddivax_asy[1:2,3],3)*100,nsmall = 1),' (',format(round(kiddivax_asy[1:2,4],3)*100,nsmall = 1),
                    ', ',format(round(kiddivax_asy[1:2,5],2)*100,nsmall = 1),')')
rownames6 <- paste0(format(round(sensitivity[1:2,3],3)*100,nsmall = 1),' (',format(round(sensitivity[1:2,4],3)*100,nsmall = 1),
                    ', ',format(round(sensitivity[1:2,5],2)*100,nsmall = 1),')')
rownames7 <- paste0(format(round(kiddivax_asy[5:6,3],2),nsmall = 1),' (',format(round(kiddivax_asy[5:6,4],2),nsmall = 1),
                    ', ',format(round(kiddivax_asy[5:6,5],2),nsmall = 1),')')

rownames8 <- paste0(format(round(sensitivity[5:6,3],2),nsmall = 1),' (',format(round(sensitivity[5:6,4],2),nsmall = 1),
                    ', ',format(round(sensitivity[5:6,5],2),nsmall = 1),')')

rownames9 <- paste0(format(round(kiddivax_asy[c(4,8),3],3)*100,nsmall = 1),' (',format(round(kiddivax_asy[c(4,8),4],3)*100,nsmall = 1),
                    ', ',format(round(kiddivax_asy[c(4,8),5],2)*100,nsmall = 1),')')
rownames10 <- paste0(format(round(sensitivity[c(4,8),3],3)*100,nsmall = 1),' (',format(round(sensitivity[c(4,8),4],3)*100,nsmall = 1),
                    ', ',format(round(sensitivity[c(4,8),5],2)*100,nsmall = 1),')')


###

pdf("Figure_table_code/figure1_update.pdf",width=14, height=10.5)

par(mar=c(0,1,0,1))
layout(matrix(c( rep(c(rep(1,2),rep(2,2),rep(3,2),rep(4,3)),3) , rep(c(rep(5,3),rep(6,3),rep(7,3)),2) ),ncol=5) ) 
#### panel A
plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(-11,17.5), ylim=c(0.4,2.5),type="n")

axis(1,at= -3:1,labels=c('0%','10%','20%','30%','40%'),cex.axis=.9,pos=0.5)
axis(1,at=9:13,labels =c('0%','10%','20%','30%','40%'),cex.axis=.9,pos =0.5)

cc <- c(1.4,1.0)

points(kiddivax_asy[c(3,7),3]*10+9,cc,pch=16)
points(sensitivity[c(3,7),3]*10-3,cc,pch=16)

polygon(c(-11.5,-11.5,18,18),c(1.25,1.55,1.55,1.25),col=rgb(0,0,0,0.05),border=F)  

lines(c(kiddivax_asy[3,4]*10+9,kiddivax_asy[3,5]*10+9),rep(cc[1],2))
lines(c(kiddivax_asy[7,4]*10+9,kiddivax_asy[7,5]*10+9),rep(cc[2],2))
lines(c(sensitivity[3,4]*10-3,sensitivity[3,5]*10-3),rep(cc[1],2))
lines(c(sensitivity[7,4]*10-3,sensitivity[7,5]*10-3),rep(cc[2],2))

for (i in 1:2) {
  
  text(16,cc[i],rownames3[i],las=1,cex = 1.1)
  text(4.7,cc[i],rownames4[i],las=1,cex = 1.1)
}

text(-9.5,cc[1],rownames[1],las=1,cex = 1.3)
text(-9.7,cc[2],rownames[2],las=1,cex = 1.3)
text(-12,1.8,"The probability of infection in community during the whole pandemic",font = 2,cex=1.32,pos=4)
lines(c(-12,18),c(2,2),lty=1,col='black',lwd=1.4)

text(4.5,2.2,'Probability (%)',cex=1.2)
text(16,2.2,'Probability (%)',cex=1.2)
text(-11.6,2.3,'A',font = 2,cex = 2.3)

text(4.5,2.4,'Main analysis',font = 2,cex=1.45)
text(15.8,2.4,'Alternative analysis',font = 2,cex = 1.45)

########## household
plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(-11,17.5), ylim=c(0.4,2.7),type="n")

axis(1,at= -3:1,labels=c('0%','10%','20%','30%','40%'),cex.axis=.9,pos=0.6)
axis(1,at=9:13,labels =c('0%','10%','20%','30%','40%'),cex.axis=.9,pos =0.6)

cc <- c(1.4,1.0)

points(kiddivax_asy[c(4,8),3]*10+9,cc,pch=16)
points(sensitivity[c(4,8),3]*10-3,cc,pch=16)

polygon(c(-11.5,-11.5,18,18),c(1.25,1.55,1.55,1.25),col=rgb(0,0,0,0.05),border=F)  

for (i in c(4,8)) {
  lines(c(kiddivax_asy[i,4]*10+9,kiddivax_asy[i,5]*10+9),rep(cc[i/4],2))
  lines(c(sensitivity[i,4]*10-3,sensitivity[i,5]*10-3),rep(cc[i/4],2))
  
  text(16,cc[i/4],rownames9[i/4],las=1,cex = 1.1)
  text(4.7,cc[i/4],rownames10[i/4],las=1,cex = 1.1)
  
  #text(-8.5,cc[i],rownames7[i],las=1,cex = 1.2)
  
}
text(-9.5,cc[1],rownames[1],las=1,cex = 1.3)
text(-9.7,cc[2],rownames[2],las=1,cex = 1.3)

text(-12,  2,"Probability of transmission from a symptomatic case to another household member",font = 2,cex=1.32,pos=4)

#### panel B
plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(-11,17.5), ylim=c(0.4,2.7),type="n")

axis(1,at= -3:1,labels=c('15%','30%','45%','60%','75%'),cex.axis=.9,pos=1)
axis(1,at=9:13,labels =c('15%','30%','45%','60%','75%'),cex.axis=.9,pos =1)

cc <- c(1.6,1.2)

points(kiddivax_asy[1:2,3]/.15+8,cc,pch=16)
points(sensitivity[1:2,3]/.15-4,cc,pch=16)

polygon(c(-11.5,-11.5,18,18),c(1.45,1.75,1.75,1.45),col=rgb(0,0,0,0.05),border=F)  

for (i in 1:2) {
  lines(c(kiddivax_asy[i,4]/.15+8,kiddivax_asy[i,5]/.15+8),rep(cc[i],2))
  lines(c(sensitivity[i,4]/.15-4,sensitivity[i,5]/.15-4),rep(cc[i],2))
  
  text(16,cc[i],rownames5[i],las=1,cex = 1.1)
  text(4.7,cc[i],rownames6[i],las=1,cex = 1.1)
  
  #text(-8.5,cc[i],rownames7[i],las=1,cex = 1.2)
  
}
text(-9.5,cc[1],rownames[1],las=1,cex = 1.3)
text(-9.7,cc[2],rownames[2],las=1,cex = 1.3)

text(-12,2.2,"Probability of cases being symptomatic",font = 2,cex=1.32,pos=4)
text(11,2.2,"Probability of cases having ARI",font = 2,cex=1.32)



#### panel C
plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(-11,17.5), ylim=c(0,3.2),type="n")

axis(1,at= -3:1,labels=c(0.25,0.5,1,2,4),cex.axis=.9,pos=0.3)
axis(1,at=9:13,labels =c(0.25,0.5,1,2,4),cex.axis=.9,pos =0.3)

axis(1,at= -3:1,labels=c(0.25,0.5,1,2,4),cex.axis=.9,pos=1.98)
axis(1,at=9:13,labels =c(0.25,0.5,1,2,4),cex.axis=.9,pos =1.98)

cc <- c(2.3,0.7)

points(log2(kiddivax_asy[5:6,3])+11,cc,pch=16)
points(log2(sensitivity[5:6,3])-1,cc,pch=16)


for (i in 5:6) {
  text(16,cc[i-4],rownames7[i-4],las=1,cex = 1.1)
  text(4.7,cc[i-4],rownames8[i-4],las=1,cex = 1.1)
  
  if (kiddivax_asy[i,4] < 0.25) {
    kiddivax_asy[i,4] <- 0.25
    arrows(x0=9,y0=0.7,x1=8.8,y1=0.7,length = 0.05)
  }
  if (sensitivity[i,4] < 0.25) {
    sensitivity[i,4] <- 0.25
    arrows(x0=-3,y0=0.7,x1=-3.2,y1=0.7,length = 0.05)
  }
  lines(log2(c(kiddivax_asy[i,4],kiddivax_asy[i,5]))+11,rep(cc[i-4],2))
  lines(log2(c(sensitivity[i,4],sensitivity[i,5]))-1,rep(cc[i-4],2))
  #text(-9.5,cc[i-4],rownames[i],las=1,cex = 1.1)
  
}

polygon(c(-11.5,-11.5,18,18),c(2.5,2.1,2.1,2.5),col=rgb(0,0,0,0.05),border=F)
polygon(c(-11.5,-11.5,18,18),c(0.9,0.5,0.5,0.9),col=rgb(0,0,0,0.05),border=F)

text(-12,2.9,"Relative susceptibility of children",font = 2,cex=1.3,pos=4)
text(-12,2.7,"compared with adults",font = 2,cex=1.3,pos=4)

text(-12,1.3,"Relative infectiousness of asymptomatic cases",font = 2,cex=1.3,pos=4)
text(-12,1.1,"compared with symptomatic cases",font = 2,cex=1.3,pos=4)

text(11.6,1.3,"Relative infectiousness of cases without ARI",font = 2,cex=1.3)
text(10,1.1,"compared with cases with ARI",font = 2,cex=1.3)

text(4.5,3.25,'Risk ratio (95% CI)',cex=1.3,font=2)
text(16,3.25,'Risk ratio (95% CI)',cex=1.3,font=2)
lines(c(-12,18),c(3.1,3.1),lty=1,col='black',lwd=1.4)
mtext('B',font = 2,cex = 1.5,side = 3,line = -0.7,at=-11.5)

## merge figure



library(matrixStats)

compute <- function(link,inputvalue){
  
  setwd(link)
  
  rawlist <- list.files(pattern="*.csv")
  rawlist1 <- rawlist[grepl("summary_",rawlist)]
  rawlist2 <- rawlist[grepl("summary2_",rawlist)]
  
  int_para <-  c(rep(0.6,4),
                 rep(0.1,7),
                 rep(0.05,6),
                 rep(c(0.5,-0.5),6),
                 rep(-0.5,4),rep(0.5,2))
  
  
  # children, adults
  int_para2 <- c(0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
                 0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
                 0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
                 0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
                 0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
                 0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
                 0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
                 0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
                 0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
                 0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
                 0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
                 0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005) 
  
  int_para <- as.vector(as.matrix(read.csv("para1.csv"))[,2] )
  int_para2 <- as.vector(as.matrix(read.csv("para2.csv"))[,2])
  for (i in 1:12){
    int_para2[10*(i-1)+1] <- 1- sum(int_para2[10*(i-1)+2:10])
  }
  #int_para[34] <- 0
  #int_para[35:39] <- -0.2
  
  int_para[30] <- inputvalue
  nsim <- 200 #length(rawlist1)
  tt1 <- tt2 <- matrix(NA,nsim,length(int_para))
  tt1 <- tt2 <- matrix(NA,nsim,length(int_para))
  tt12 <- tt22 <- matrix(NA,nsim,length(int_para2))
  
  CI_asym <- rep(0,nsim)
  
  for (i in 1:nsim){
    temp <- read.csv(rawlist1[i])  
    tt1[i,] <- temp[,2]
    tt2[i,] <- 1*(temp[,3] <= int_para & temp[,4] >= int_para)
    
    CI_asym[i] <- temp[30,4]
    
  
  }
  
  summary(tt1)
  summary(tt2)
  
  
  #orderlist <- c(43:48,49:51,66,52:54,68,55:57,70,58:60,72,61:63,74,19:34,2:3,1)
  orderlist <- c(1:18,20,22,24,26,28,35:39,30)
  out <- matrix(NA,29,5)
  out[,1] <- int_para[orderlist ]
  out[,2] <- colMeans(tt1)[orderlist ]
  out[,3] <- colQuantiles(tt1,probs=0.025)[orderlist ]
  out[,4] <- colQuantiles(tt1,probs=0.975)[orderlist ]
  out[,5] <- colMeans(tt2)[orderlist ]
  
  out[18:29,1:4] <- exp(out[18:29,1:4] )
  
  #out <- round(out,4)
  #out[-5,] <- round(out[-5,],2)
  
  #out[-5,] <- round(out[-5,],2)
  #out[5,1:2] <- round(out[5,1:2],4)
  #out[5,3] <- round(out[5,3],2)
  
  return(list(out,mean(CI_asym<0)))
}

plotmat <- matrix(NA,10,3)

# the actual value, assume ARI
a2 <- compute("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/simulation_result/true_value/0_0_repeat/",-0.889471)
a21 <- compute("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/simulation_result/true_value/0.2_0.2/",-0.889471)
a22 <- compute("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/simulation_result/true_value/0.2_0.4/",-0.889471)
a23 <- compute("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/simulation_result/true_value/0.4_0.2/",-0.889471)
a24 <- compute("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/simulation_result/true_value/0.4_0.4/",-0.889471)
# the actual value 2, assume any symptom
a1 <- compute("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/simulation_result/true_value2/0_0_repeat",-0.55625)
a11 <- compute("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/simulation_result/true_value2/0.2_0.2",-0.55625)
a12 <- compute("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/simulation_result/true_value2/0.2_0.4",-0.55625)
a13 <- compute("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/simulation_result/true_value2/0.4_0.2",-0.55625)
a14 <- compute("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/simulation_result/true_value2/0.4_0.4",-0.55625)



plotmat[1,] <- a1[[1]][29,2:4]
plotmat[2,] <- a11[[1]][29,2:4]
plotmat[3,] <- a12[[1]][29,2:4]
plotmat[4,] <- a13[[1]][29,2:4]
plotmat[5,] <- a14[[1]][29,2:4]
plotmat[6,] <- a2[[1]][29,2:4]
plotmat[7,] <- a21[[1]][29,2:4]
plotmat[8,] <- a22[[1]][29,2:4]
plotmat[9,] <- a23[[1]][29,2:4]
plotmat[10,] <- a24[[1]][29,2:4]









###################################################################################################################


#pdf("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/summary/2023_03_01_figure42.pdf",width=9.5, height=5)

#layout(matrix( 1:2, nrow=1))

r1 <- plotmat[1:5,1]
lb <-  plotmat[1:5,2]
ub <-  plotmat[1:5,3]

lbtext2 <- c('0%',rep(c('20%','40%'),2))
lbtext1 <- c(rep('0%',1),rep('20%',2),rep('40%',2))

par(mar=c(2,11,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,2), ylim=c(-3,2.2),type="n")

axis(1,at=c(-1,-0.5,0,0.5,1,1.5,2,5),labels=c(NA,NA,NA,NA,NA),cex.axis=1,pos = -2.35)

x <-  0:4*0.5



lines(c(-0.1,2.2),rep(log2(exp(-0.55625))+1,2),lty=2,col="red")

axis(2,at=c(-2,-1,0,1,2),labels=2^c(-3,-2,-1,0,1), las=1, pos=-0.2,cex.axis=1)

points(x,log2(r1)+1,pch=16,cex=1)

for (i in 1:length(x)) {
  lines(rep(x[i],2),log2(c(lb[i],ub[i]))+1)
}

xadj <- 0.8
x2pos <- 0.5
mtext(lbtext1,side=1,line=-2.2,at=x,cex=1)
mtext(lbtext2,side=1,line=x2pos,at=x,cex=1)
mtext('Misclassification',side = 1,line =  -2.2 - xadj,cex=0.8,at=-0.6)
mtext('probability of',side = 1,line = -2.2,cex=0.8,at=-0.66)
mtext('symptomatic cases',side = 1,line = -2.2 + xadj,cex=0.8,at=-0.549)  
mtext('Misclassification',side = 1,line = x2pos - xadj,cex=0.8,at=-0.6)
mtext('probability of',side = 1,line = x2pos,cex=0.8,at=-0.66)
mtext('asymptomatic cases',side = 1,line = x2pos + xadj,cex=0.8,at=-0.535)  

yadj <- 2.5

mtext('Relative infectiousness',side = 2,line = 3.9+yadj,cex=1.1,at  = 0)  
mtext('of asymptomatic cases',side = 2,line = 2.8+yadj,cex=1.1, at = 0)  

mtext('Main analysis',side = 3,line = 0 ,cex=1.2)  

#title(main="A", adj=0)
mtext('C',font = 2,cex = 1.5,side = 3,line = -0.7,at=-0.5)

#### B

r1 <- plotmat[6:10,1]
lb <-  plotmat[6:10,2]
ub <-  plotmat[6:10,3]

lbtext2 <- c('0%',rep(c('20%','40%'),2))
lbtext1 <- c(rep('0%',1),rep('20%',2),rep('40%',2))




plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,2), ylim=c(-3,2.2),type="n")

axis(1,at=c(-1,-0.5,0,0.5,1,1.5,2,5),labels=c(NA,NA,NA,NA,NA),cex.axis=1,pos = -2.35)

x <-  0:4*0.5


lines(c(-0.1,2.2),rep(log2(exp(-0.889471))+1,2),lty=2,col="red")

axis(2,at=c(-2,-1,0,1,2),labels=2^c(-3,-2,-1,0,1), las=1, pos=-0.2,cex.axis=1)

points(x,log2(r1)+1,pch=16,cex=1)

for (i in 1:length(x)) {
  lines(rep(x[i],2),log2(c(lb[i],ub[i]))+1)
}


xadj <- 0.8
x2pos <- 0.5
mtext(lbtext1,side=1,line=-2.2,at=x,cex=1)
mtext(lbtext2,side=1,line=x2pos,at=x,cex=1)
mtext('Misclassification',side = 1,line =  -2.2 - xadj,cex=0.8,at=-0.6)
mtext('probability of',side = 1,line = -2.2,cex=0.8,at=-0.66)
mtext('symptomatic cases',side = 1,line = -2.2 + xadj,cex=0.8,at=-0.549)  
mtext('Misclassification',side = 1,line = x2pos - xadj,cex=0.8,at=-0.6)
mtext('probability of',side = 1,line = x2pos,cex=0.8,at=-0.66)
mtext('asymptomatic cases',side = 1,line = x2pos + xadj,cex=0.8,at=-0.535)  


mtext('Relative infectiousness',side = 2,line = 3.9+yadj,cex=1.1,at  = 0)  
mtext('of asymptomatic cases',side = 2,line = 2.8+yadj,cex=1.1, at = 0)  

mtext('Alternative analysis',side = 3,line = 0 ,cex=1.2)  
#title(main="B", adj=0)

mtext('D',font = 2,cex = 1.5,side = 3,line = -0.7,at=-0.5)

## input data


#y1_ph1 <- read.csv(paste(link,"y1_ph1_0\\y1_ph1.csv",sep=""),header=F)

ILI_ph1 <- read.csv("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax/non_bracketing/data/ILILAB_ph1.csv")





#########################################
## plot figure 1

#pdf("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/summary/figure1a_test.pdf",width=6,height=4)

#layout(matrix( 1:2, nrow=1))

par(mar=c(2,4,1,1))


ILI <- ILI_ph1
data <- y1_ph1


## 275 to 914
maxl <- 0.07

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(275-90,914), ylim=c(0,0.08),type="n")

top <- 0.002

lines(rep(276-14,2),c(maxl+0.001,maxl+top))
lines(rep(303-14,2),c(maxl+0.001,maxl+top))
lines(c(276,303)-14,c(maxl+top,maxl+top))

lines(rep(425-14,2),c(maxl+0.001,maxl+top))
lines(rep(600-14,2),c(maxl+0.001,maxl+top))
lines(c(425,600)-14,c(maxl+top,maxl+top))

lines(rep(655-14,2),c(maxl+0.001,maxl+top))
lines(rep(684-14,2),c(maxl+0.001,maxl+top))
lines(c(655,684)-14,c(maxl+top,maxl+top))

lines(rep(780-14,2),c(maxl+0.001,maxl+top))
lines(rep(894-14,2),c(maxl+0.001,maxl+top))
lines(c(780,894)-14,c(maxl+top,maxl+top))

lev1 <- 0.006
# 
# lines(rep(276/2+303/2-14,2),c(maxl+lev1+0.001,maxl+lev1+top))
# lines(rep(425/2+600/2-14,2),c(maxl+lev1+0.001,maxl+lev1+top))
# lines(rep(655/2+684/2-14,2),c(maxl+lev1+0.001,maxl+lev1+top))
# lines(rep(780/2+894/2-14,2),c(maxl+lev1+0.001,maxl+lev1+top))
# 
# p1 <- 276/2+303/2-14
# p2 <- 425/2+600/2-14
#   
# lines(c(p1,(p1+p2)/2-30),rep(maxl+lev1+top,2))
# lines(c((p1+p2)/2+30,p2),rep(maxl+lev1+top,2))
# mtext("246",side = 3,at=(p1+p2)/2,line=-1.5,cex=0.8)
# 
# p1 <- 425/2+600/2-14
# p2 <- 655/2+684/2-14
# lines(c(p1,(p1+p2)/2-30),rep(maxl+lev1+top,2))
# lines(c((p1+p2)/2+30,p2),rep(maxl+lev1+top,2))
# mtext("698",side = 3,at=(p1+p2)/2,line=-1.5,cex=0.8)
# 
# p1 <- 655/2+684/2-14
# p2 <- 780/2+894/2-14
# lines(c(p1,(p1+p2)/2-30),rep(maxl+lev1+top,2))
# lines(c((p1+p2)/2+30,p2),rep(maxl+lev1+top,2))
# mtext("676",side = 3,at=(p1+p2)/2,line=-1.5,cex=0.8)
# 
# 
# lev1 <- 0.006
# lev2 <- 0.004
# lines(rep(425/2+600/2-14,2),c(maxl+lev1+lev2+0.001,maxl+lev1+top+lev2))
# lines(rep(780/2+894/2-14,2),c(maxl+lev1+lev2+0.001,maxl+lev1+top+lev2))
# 
# p1 <- 425/2+600/2-14
# p2 <- 780/2+894/2-14
# lines(c(p1,(p1+p2)/2-40),rep(maxl+lev1+top+lev2,2))
# lines(c((p1+p2)/2+40,p2),rep(maxl+lev1+top+lev2,2))
# mtext("1126",side = 3,at=(p1+p2)/2,line=-0.6,cex=0.8)


mtext("R1",side = 3,at=(276+303)/2-14,line=-2.2,cex=0.8)
mtext("R2",side = 3,at=(425+600)/2-14,line=-2.2,cex=0.8)
mtext("R3",side = 3,at=(655+684)/2-14,line=-2.2,cex=0.8)
mtext("R4",side = 3,at=(780+894)/2-14,line=-2.2,cex=0.8)


#lines((275-90):914,ILI[(275-90):914,1],col=rgb(0,0,0,1))

proxy <- (275-90):914
polygon(proxy[c(1,1:length(proxy),length(proxy),1)],
        c(0,ILI[proxy,1],0,0),col=rgb(1,0,0,0.5),border=F)



axis(1,at=274-90+cumsum(c(1,90,91,92,92,90,91,92,92)),labels=c("1 Jan 09","1 Apr 09","1 Jul 09","1 Oct 09","1 Jan 10","1 Apr 10","1 Jul 10","1 Oct 10","1 Jan 11"),cex.axis=0.95)
axis(2,at=0.01*0:7, las=1, pos=275-90)

# 
# step <- maxl/nrow(data)
# 
# pl <- data[order(-data[,5]),c(7,9,11,13,13,5)]-14
# pl[,6] <- pl[,6]+14
# pl[!is.na(pl[,3]),5] <- NA 
# #pl2 <- data[is.na(data[,7]),c(7,9,11)]
# 
# for ( i in 1:nrow(data) ){
# lines(pl[i,1:2],rep(maxl-i*step,2),col=rgb(1,0.5,0,0.2))
# lines(pl[i,2:3],rep(maxl-i*step,2),col=rgb(0,1,0,0.05))
# lines(pl[i,3:4],rep(maxl-i*step,2),col=rgb(0,0,1,0.05))
# lines(pl[i,c(2,5)],rep(maxl-i*step,2),col=rgb(0,0,0,0.05))
# 
# }
# 
# lines(c(930,930),c(0,0.07))
# lines(c(930,950),c(0,0))
# lines(c(930,950),rep(0.07*(673/2097),2))
# lines(c(930,950),rep(0.07*(1-183/2097),2))
# lines(c(930,950),c(0.07,0.07))
# 




mtext("Influenza activity", side=2, line=3)

#mtext("Children", side=4, line=0,at=(183+1241+673/2) /2097*0.07,cex=0.7)
#mtext("Adults", side=4, line=0,at=(1241/2+183) /2097*0.07,cex=0.7)
#mtext("Elderly", side=4, line=0,at=183 /2097*0.5*0.07,cex=0.7)

#mtext("Older adults", side=4, line=0,at=(673+1241+183/2) /2097*0.07,cex=0.7)
#mtext("Adults", side=4, line=0,at=(1241/2+673) /2097*0.07,cex=0.7)
#mtext("Children", side=4, line=0,at=673 /2097*0.5*0.07,cex=0.7)

#title(main="A", adj=0)

mtext('E',font = 2,cex = 1.5,side = 3,line = -1.7,at=185-15)


dev.off()