### this is used to generate the result data

load("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/analysis_result/v25_data_v1_ari/image_0.443255802383646.Rdata")



ILI <- read.csv("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/analysis_result/v25_data_v1_ari/ILILAB_2019_04_25.csv")
adjf <- 182-14
ILI <- ILI[-c(1:adjf),]

mcmc1 <- tt[[1]][inc,]
mcmc2 <- tt[[2]][inc,]

d1 <- matrix(NA,10000,24)
d1[,1] <- 1-exp(- (mcmc1[,5]*sum(ILI[552:670-adjf,1])+mcmc1[,6]*sum(ILI[671:747-adjf,1])))
d1[,7] <- 1-exp(- (exp(mcmc1[,18]))*(mcmc1[,5]*sum(ILI[552:670-adjf,1])+mcmc1[,6]*sum(ILI[671:747-adjf,1])))

indrow <- list(944:1020,1105:1153,1532:1636,1875:1937,2022:2112) 
for (i in 1:5){
  d1[,1+i]  <- 1 - exp(- mcmc1[,6+i]*sum(ILI[indrow[[i]]- adjf,1+i%%2]))
  d1[,7+i]  <- 1 - exp(- (exp(mcmc1[,18+2*i]))*mcmc1[,6+i]*sum(ILI[indrow[[i]]- adjf,1+i%%2]))
}

for (i in 1:6){
  d1[,12+i] <-  1 - exp(- (exp(mcmc1[,16+2*i]))*mcmc1[,11+i])
  d1[,18+i] <-  1 - exp(- (mcmc1[,11+i]))
}

z2 <- para_summary(d1,4,3,0)


a1 <- data.frame(cbind(1,z1))

a1 <- a1[-c(11,19,21,23,25,27,29,31:34),-5]
a1[5:16,2:4] <- z2[7:18,1:3]
a1[17:28,2:4] <- exp(a1[17:28,2:4])
a1[28+1:12,2:4] <- z2[c(1:6,19:24),1:3]

a1[1,1] <- "children.pH1N1.symptomatic.probability"
a1[2,1] <- "adults.pH1N1.symptomatic.probability"
a1[3,1] <- "children.H3N2.symptomatic.probability"
a1[4,1] <- "adults.H3N2.symptomatic.probability"
a1[1:6+4,1] <- paste("child.coumminty.risk",1:6,sep=".")
a1[1:6+6+4,1] <- paste("child.household.risk",1:6,sep=".")
a1[1:6+12+4,1] <- paste("children.relative.susceptibility",1:6,sep=".")
a1[1+18+4,1] <- "asymptomatic.relative.transmissibility"
a1[1:5+1+18+4,1] <- paste("2-fold higher of HAI titer",2:6,sep=".")
a1[1:6+28,1] <- paste("adult.coumminty.risk",1:6,sep=".")
a1[1:6+34,1] <- paste("adult.household.risk",1:6,sep=".")



names(a1)[2:4] <- c("estimate","CI_lower","CI_upper")


out <- a1[c(1:2,5,11,17,23,29,35.1),]

write.csv(out,"/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/data/2022_10_24_result_ari.csv")


#############

load("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/analysis_result/v25_data_v1_any/image_0.575898563256487.Rdata")



ILI <- read.csv("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/analysis_result/v25_data_v1_any/ILILAB_2019_04_25.csv")
adjf <- 182-14
ILI <- ILI[-c(1:adjf),]

mcmc1 <- tt[[1]][inc,]
mcmc2 <- tt[[2]][inc,]

d1 <- matrix(NA,10000,24)
d1[,1] <- 1-exp(- (mcmc1[,5]*sum(ILI[552:670-adjf,1])+mcmc1[,6]*sum(ILI[671:747-adjf,1])))
d1[,7] <- 1-exp(- (exp(mcmc1[,18]))*(mcmc1[,5]*sum(ILI[552:670-adjf,1])+mcmc1[,6]*sum(ILI[671:747-adjf,1])))

indrow <- list(944:1020,1105:1153,1532:1636,1875:1937,2022:2112) 
for (i in 1:5){
  d1[,1+i]  <- 1 - exp(- mcmc1[,6+i]*sum(ILI[indrow[[i]]- adjf,1+i%%2]))
  d1[,7+i]  <- 1 - exp(- (exp(mcmc1[,18+2*i]))*mcmc1[,6+i]*sum(ILI[indrow[[i]]- adjf,1+i%%2]))
}

for (i in 1:6){
  d1[,12+i] <-  1 - exp(- (exp(mcmc1[,16+2*i]))*mcmc1[,11+i])
  d1[,18+i] <-  1 - exp(- (mcmc1[,11+i]))
}

z2 <- para_summary(d1,4,3,0)


a1 <- data.frame(cbind(1,z1))

a1 <- a1[-c(11,19,21,23,25,27,29,31:34),-5]
a1[5:16,2:4] <- z2[7:18,1:3]
a1[17:28,2:4] <- exp(a1[17:28,2:4])
a1[28+1:12,2:4] <- z2[c(1:6,19:24),1:3]

a1[1,1] <- "children.pH1N1.symptomatic.probability"
a1[2,1] <- "adults.pH1N1.symptomatic.probability"
a1[3,1] <- "children.H3N2.symptomatic.probability"
a1[4,1] <- "adults.H3N2.symptomatic.probability"
a1[1:6+4,1] <- paste("child.coumminty.risk",1:6,sep=".")
a1[1:6+6+4,1] <- paste("child.household.risk",1:6,sep=".")
a1[1:6+12+4,1] <- paste("children.relative.susceptibility",1:6,sep=".")
a1[1+18+4,1] <- "asymptomatic.relative.transmissibility"
a1[1:5+1+18+4,1] <- paste("2-fold higher of HAI titer",2:6,sep=".")
a1[1:6+28,1] <- paste("adult.coumminty.risk",1:6,sep=".")
a1[1:6+34,1] <- paste("adult.household.risk",1:6,sep=".")



names(a1)[2:4] <- c("estimate","CI_lower","CI_upper")


out <- a1[c(1:2,5,11,17,23,29,35.1),]

write.csv(out,"/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/code_upload/data/2022_10_24_result_any.csv")

