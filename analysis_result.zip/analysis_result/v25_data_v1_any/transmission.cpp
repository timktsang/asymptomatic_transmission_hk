#include <RcppArmadilloExtensions/sample.h>
#include <Rcpp.h>
#include <RcppParallel.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::depends(RcppParallel)]]
using namespace Rcpp ;
using namespace RcppParallel;

//########################################################################################################################################
//function for computing the serial interval density
// [[Rcpp::export]]
NumericVector serial_density(double p1,
double p2){
NumericVector a=NumericVector::create(1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,11.0,12.0,13.0,14.0);
return (pweibull(a+1,p1,p2)-pweibull(a,p1,p2));
}


//########################################################################################################################################
// function to generate normal random variable
// [[Rcpp::export]]
double rnorm(double a, double b) { // a: mean, b: s.d.
	double c=a+b*sum(rnorm(1));
    return c;
}

//########################################################################################################################################
// function to generate normal random variable
// [[Rcpp::export]]
double gen_gamma(const double a, const double b) { // a: mean, b: s.d.
    return R::rgamma(a,b);
}

// directly call gamma(double) for gamma function

//########################################################################################################################################
// function to generate binomial random number
// [[Rcpp::export]]
int gen_binom(const double p){
double cut=(double)rand()/(RAND_MAX);
int out=0;
if (cut<p){
out=1;
}
return out;
}


//########################################################################################################################################
// function to general multiviariable normal given sigma
// [[Rcpp::export]]
NumericVector rmnorm(arma::mat sigma) {
int ncols=sigma.n_cols;
arma::rowvec c=arma::randn(1,ncols);
arma::rowvec a=c*arma::chol(sigma);   
NumericVector b=NumericVector(a.begin(),a.end());   
return b;
}

//########################################################################################################################################
//function to compute the prior likelihood 
// [[Rcpp::export]]
double prior_loglik(NumericVector para){
// check if the para are within their possible range
NumericVector out(para.length());
int b1;
for (b1=38;b1>=17;--b1){
out(b1)=R::dnorm(para(b1),0.0,3.0,1); 
}
for (b1=16;b1>=4;--b1){
out(b1)=R::dunif(para(b1),0.000001,9.99,1); 
}
for (b1=3;b1>=0;--b1){
out(b1)=R::dunif(para(b1),0.01,0.99,1); 
}

double output=sum(out);
if (output < -9999999){
output=-9999999;
}

return output;
}

//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel for doing simulation
struct SimData:public Worker{
// source vector
RMatrix<int> data;
RMatrix<int> data1;
RMatrix<int> data1_full;
RMatrix<int> sym;
RMatrix<int> sym1;
RMatrix<double> ILI;
RVector<double> para;
RVector<double> para2;
RVector<double> SI;
RVector<double> miss_ind;
RMatrix<double> record;
RMatrix<double> record2;
double aviprob;
// destination vector
// initialize with source and destination
SimData(IntegerMatrix data,
IntegerMatrix data1,
IntegerMatrix data1_full,
IntegerMatrix sym,
IntegerMatrix sym1,
NumericMatrix ILI,
NumericVector para,
NumericVector para2,
NumericVector SI,
NumericVector miss_ind,
NumericMatrix record,
NumericMatrix record2,
double aviprob) 
:data(data),data1(data1),data1_full(data1_full),sym(sym),sym1(sym1),ILI(ILI),para(para),para2(para2),SI(SI),miss_ind(miss_ind),record(record),record2(record2),aviprob(aviprob){}
void operator()(std::size_t begin, std::size_t end) {

// section to write the parallel version
// functor (pass input and output matrixes)
for (unsigned int b1=begin;b1<end;++b1){	
int b2;
int b3;
int b4;
int b5;

// here generate the baseline titer level
// first select 0-9
for (b2=data1(b1,1)-1;b2>=0;--b2){
//if (data(b1,5+b2*5+4)==-1){	
double titerlevel1=((double)rand()/(RAND_MAX));
for (b3=9;b3>=0;--b3){
titerlevel1-=para2[b3+10*(data1(b1,5+b2*5+3)>=18)+20*data1(b1,45)];
if (titerlevel1<0){
data1(b1,5+b2*5+4)=b3;
// break out from the loop 
break;
}
}
//}
}


// here start to generate the infection status
// first generate the sus parameber
double sus[int(data1(b1,1))];
for (b3=data1(b1,1)-1;b3>=0;--b3){
sus[b3]=exp(para[33+data1(b1,45)]*(data1(b1,5+b3*5+4))+para[17+2*data1(b1,45)]*(data1(b1,5+b3*5+3)<18)+para[18+2*data1(b1,45)]*(data1(b1,5+b3*5+3)>50));
}

// 499 is the change point
// b2 is time index
for (b2=data1(b1,2)+1;b2<=data1(b1,3);++b2){
// b3 is participant index
for (b3=data1(b1,1)-1;b3>=0;--b3){	
// at risk 	
if (data1(b1,5+b3*5)==0){ 
// community risk
double hazard1=ILI(b2-1,data1(b1,46))*para[ (4+1*(b2>509))*(data1(b1,45)==0) + (5+data1(b1,45))*(data1(b1,45)>0) ]; //*pow(3,b2>509); //+3*(b2>509)
// household risk
for (b4=data1(b1,1)-1;b4>=0;--b4){
if (b4!=b3){
// need to with the range of serial interval to have contribution
if ((b2-data1(b1,5+b4*5+1)>0)&&(b2-data1(b1,5+b4*5+1)<=10)){	
// need to -1 beacuse the index is from 0 to 9
// transmissibility for asymptomatic vs symptomatic
hazard1+=para[11+data1(b1,45)]*SI[b2-data1(b1,5+b4*5+1)-1]*exp(para[29]*(data1(b1,5+b4*5+2)==0)); 
}
}
}

int inf=gen_binom(1-exp(-hazard1*sus[b3]));

if (inf==1){
data1(b1,5+5*b3)=1;
// infection time
data1(b1,5+5*b3+1)=b2;
// symptom
data1(b1,5+5*b3+2)=R::rbinom(1,para[0+1*(data1(b1,5+5*b3+3)>=18)+2*data1(b1,46)]);
}

}
}
}

//for (b3=data1(b1,1)-1;b3>=0;--b3){
// here add the symptom status for non infection
//if (data1(b1,5+5*b3)==0){
//data1(b1,5+5*b3+2)=gen_binom(para[33+1*(data1(b1,5+5*b3+3)>=18)]);	
//}
//}

// here need to remeber that the pcr is due to trigger of household visit, so the availability is clustered

// here based on the infection status, generate symptom time

for (b2=data1.ncol()-1;b2>=0;--b2){
data1_full(b1,b2)=data1(b1,b2);	
}

// the probability that it is household visit and hence known infection time in cluster (a small probability)
int avisym=gen_binom(aviprob);
record(b1,0)=avisym+100;
// missing infeciton time
if (miss_ind[0]){

for (b2=data1(b1,1)-1;b2>=0;--b2){
if (data1(b1,5+5*b2)==1){
if (avisym==1){
sym1(b1,b2*20+0)=data1(b1,5+5*b2+1);
}
else{

// symptomatic infection	
if (data1(b1,5+5*b2+2)==1){
// here generate the number of symptom first
sym1(b1,b2*20)=data1(b1,5+5*b2+1);
int symnumber=R::rpois(2.5);


double prob[int(data1(b1,3))];
double totalprob=0;

// get the probability vector
for (b4=data1(b1,3);b4>data1(b1,2);--b4){
prob[b4-1]=1;
totalprob+=prob[b4-1];
}
// remove the infected time
int blackoutmax=sym1(b1,b2*20)+20;
if (blackoutmax>data1(b1,3)){
blackoutmax=data1(b1,3)-1;
}
for (b5=blackoutmax;b5>=sym1(b1,b2*20)-20;--b5){
totalprob-=prob[b5-1];
prob[b5-1]=0;
}

for (b3=symnumber-1;b3>=0;--b3){
// here propose the infection time
double gen=((double)rand()/(RAND_MAX));
gen*=totalprob;
for (b4=data1(b1,3)-1;b4>data1(b1,2)-1;--b4){
gen-=prob[b4];
if (gen<0){
sym1(b1,b2*20+b3+1)=b4+1;
// break out from the loop 
break;
}
}
int blackoutmax=sym1(b1,b2*20+b3+1)+20;
if (blackoutmax>data1(b1,3)){
blackoutmax=data1(b1,3)-1;
}
for (b5=blackoutmax;b5>=sym1(b1,b2*20+b3+1)-20;--b5){
totalprob-=prob[b5-1];
prob[b5-1]=0;
}

}

data1(b1,5+5*b2+1)=-1;

}
else{
//asymptomatoc infection

//int mid=(data1(b1,2)+data1(b1,3))/2;
//if (data1(b1,5+5*b2+1)<mid){
//sym1(b1,b2*20+0)=data1(b1,2);
//sym1(b1,b2*20+1)=mid;
//}
//else{	
//sym1(b1,b2*20+0)=mid;
//sym1(b1,b2*20+1)=data1(b1,3);
//}

sym1(b1,b2*20+0)=data1(b1,2);
sym1(b1,b2*20+1)=data1(b1,3);
data1(b1,5+5*b2+1)=-1;
}

}

}

}

}

// here replace the missing
if ((miss_ind[1])&&(avisym==0)){
for (b2=data1(b1,1)-1;b2>=0;--b2){	
if (data(b1,5+5*b2)==-1){
data1(b1,5+5*b2)=-1;
data1(b1,5+5*b2+1)=-1;	
data1(b1,5+5*b2+2)=0;
for (b3=19;b3>=0;--b3){
sym1(b1,b2*20+b3)=-1;
}
sym1(b1,b2*20)=data1(b1,2);
sym1(b1,b2*20+1)=data1(b1,3);
}
}
}

if (miss_ind[2]){
for (b2=data1(b1,1)-1;b2>=0;--b2){	
// here replace the titer
if (data(b1,5+5*b2+4)==-1){
data1(b1,5+5*b2+4)=-1;	
}
}
}





}
}
};

//########################################################################################################################################
//function to do simulation
// [[Rcpp::export]]
List sim_data(IntegerMatrix data,
IntegerMatrix sym,
NumericMatrix ILI,
NumericVector para,
NumericVector para2,
NumericVector miss_ind,
double aviprob){
// clone the data first
IntegerMatrix data1(clone(data)); // output
IntegerMatrix data1_full(clone(data));
IntegerMatrix sym1(clone(sym)); // output

NumericMatrix record(data1.nrow(),10);
NumericMatrix record2(1,1);

// compute the serial_density to use
NumericVector SI=serial_density(4.98,3.49);

int b1=1;
int b2;
int b3;
for (b1=data1.nrow()-1;b1>=0;--b1){
// here clean out the infection status, and let them to be missing
for (b2=data1(b1,1)-1;b2>=0;--b2){
// copying the age	
data1(b1,5+b2*5+0)=0;
data1(b1,5+b2*5+1)=-1;
data1(b1,5+b2*5+2)=-1;
for (b3=19;b3>=0;--b3){
sym1(b1,b2*20+b3)=-1;
}
}
}


SimData simdata1(data,data1,data1_full,sym,sym1,ILI,para,para2,SI,miss_ind,record,record2,aviprob);
// call parallelFor to do the work
parallelFor(0,data1.nrow(),simdata1);



return List::create(_[""]=data1,
_[""]=sym1,	
_[""]=data1_full,
_[""]=record,
_[""]=record2);
} 




//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel function
struct LogLik:public Worker{
// source vector
RMatrix<double> out1;
RMatrix<double> out2;
RMatrix<double> out3;
RMatrix<int> data1;
RMatrix<int> data;
RMatrix<double> ILI;
RVector<double> para;
RVector<double> para2;
RVector<double> SI;
int level1;
int level2;
int level3;
// destination vector
// initialize with source and destination
LogLik(NumericMatrix out1,
NumericMatrix out2,
NumericMatrix out3,
IntegerMatrix data1,
IntegerMatrix data,
NumericMatrix ILI,
NumericVector para,
NumericVector para2,
NumericVector SI,
int level1,
int level2,
int level3) 
:out1(out1),out2(out2),out3(out3),data1(data1),data(data),ILI(ILI),para(para),para2(para2),SI(SI),level1(level1),level2(level2),level3(level3){}
void operator()(std::size_t begin, std::size_t end) {

// section to write the parallel version
// functor (pass input and output matrixes)
for (unsigned int b1=begin;b1<end;++b1){
int b2;
int b3;
int b4;
int b5;

// level1: symptom likelihood
// based on those with known infection status only, to avoid feedback problem
if (level1){
for (b2=data1(b1,1)-1;b2>=0;--b2){	
if (data(b1,5+5*b2)==1){
double symprob=para[0+1*(data1(b1,5+5*b2+3)>=18)+2*data1(b1,46)];
out1(b1,b2)=data1(b1,5+5*b2+2)*log(symprob)+(1-data1(b1,5+5*b2+2))*log(1-symprob);
}
else{
//double symprob=para[33+1*(data1(b1,5+5*b2+3)>=18)];
//out1(b1,b2)=data1(b1,5+5*b2+2)*log(symprob)+(1-data1(b1,5+5*b2+2))*log(1-symprob);	
}
}	
}


// level2: baseline titer dist
// based on those with known titer only, to avoid feedback problem
if (level2){
for (b2=data1(b1,1)-1;b2>=0;--b2){	
if (data(b1,5+b2*5+4)!=-1){
out2(b1,b2)=log(para2[10*(data1(b1,5+b2*5+3)>=18)+data1(b1,5+b2*5+4)+20*data1(b1,45)]);
}
}
}


// level3: the transmsision likelihood
if (level3){
for (b3=data1(b1,1)-1;b3>=0;--b3){

// first generate the sus parameber
double sus;
sus=exp(para[33+data1(b1,45)]*(data1(b1,5+b3*5+4))+para[17+2*data1(b1,45)]*(data1(b1,5+b3*5+3)<18)+para[18+2*data1(b1,45)]*(data1(b1,5+b3*5+3)>50));

// the final date for contribution from non-infection
int finaltime=data1(b1,3)+1;
if (data1(b1,5+5*b3)==1){
finaltime=data1(b1,5+5*b3+1);	
}

double h[finaltime];
// fill the community risk
for (b2=finaltime;b2>data1(b1,2);--b2){
h[b2-1]=ILI(b2-1,data1(b1,46))*para[ (4+1*(b2>509))*(data1(b1,45)==0) + (5+data1(b1,45))*(data1(b1,45)>0) ];	
}

for (b4=data1(b1,1)-1;b4>=0;--b4){
if (b4!=b3){
if (data1(b1,5+b4*5+1)!=-1){
for (b5=9;b5>=0;--b5){
if (data1(b1,5+b4*5+1)+b5+1<=finaltime){
double hrisk=0;
hrisk=para[11+data1(b1,45)]*exp(para[29]*(data1(b1,5+b4*5+2)==0)); 
h[data1(b1,5+b4*5+1)+b5]+=hrisk*SI[b5];
}
}
}
}	
}

for (b2=finaltime-1;b2>data1(b1,2);--b2){
out3(b1,2*b3)-=h[b2-1]*sus;	
}
if (data1(b1,5+5*b3)==1){
out3(b1,2*b3+1)+=log(1-exp(-h[finaltime-1]*sus));	
}

}



}


}
}
};

//########################################################################################################################################
// function to likelihood
// given the full data set, compute the likelihood
// [[Rcpp::export]]
List loglik(IntegerMatrix data1,
IntegerMatrix data,
NumericMatrix ILI,	
NumericVector para,
NumericVector para2,
NumericVector SI,
int level1,
int level2,
int level3){
// check if the para are within their possible range
NumericMatrix out1(data1.nrow(),8);
NumericMatrix out2(data1.nrow(),8);
NumericMatrix out3(data1.nrow(),16);
// call parallel program
LogLik loglik(out1,out2,out3,data1,data,ILI,para,para2,SI,level1,level2,level3);
// call parallelFor to do the work
parallelFor(0,data1.nrow(),loglik);

return List::create(_[""]=out1,
	_[""]=out2,
	_[""]=out3);
}






//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel function
struct AllUpdate:public Worker{
// source vector
RMatrix<int> data1out;
RMatrix<int> data1pro;
RMatrix<double> loglik1out;
RMatrix<double> loglik2out;
RMatrix<double> loglik3out;
RMatrix<double> loglik1pro;
RMatrix<double> loglik2pro;
RMatrix<double> loglik3pro;
RMatrix<double> mcmcrecord;
RMatrix<int> data1;
RMatrix<int> data;
RMatrix<int> sym;
RMatrix<double> ILI;
RVector<double> para;
RVector<double> para2;
RVector<double> SI;
int member;
RMatrix<double> loglik1;
RMatrix<double> loglik2;
RMatrix<double> loglik3;
RMatrix<double> temprecord;
// destination vector
// initialize with source and destination
AllUpdate(IntegerMatrix data1out,
IntegerMatrix data1pro,
NumericMatrix loglik1out,
NumericMatrix loglik2out,
NumericMatrix loglik3out,
NumericMatrix loglik1pro,
NumericMatrix loglik2pro,
NumericMatrix loglik3pro,
NumericMatrix mcmcrecord,
IntegerMatrix data1,
IntegerMatrix data,
IntegerMatrix sym,
NumericMatrix ILI,
NumericVector para,
NumericVector para2,
NumericVector SI,
int member,
NumericMatrix loglik1,
NumericMatrix loglik2,
NumericMatrix loglik3,
NumericMatrix temprecord) 
:data1out(data1out),data1pro(data1pro),loglik1out(loglik1out),loglik2out(loglik2out),loglik3out(loglik3out),loglik1pro(loglik1pro),loglik2pro(loglik2pro),loglik3pro(loglik3pro),mcmcrecord(mcmcrecord),data1(data1),data(data),sym(sym),ILI(ILI),para(para),para2(para2),SI(SI),member(member),loglik1(loglik1),loglik2(loglik2),loglik3(loglik3),temprecord(temprecord){}

void operator()(std::size_t begin, std::size_t end) {

// section to write the parallel version
// functor (pass input and output matrixes)
for (unsigned int b1=begin;b1<end;++b1){
int b2;
int b3;
int b4;
int b5;

if (member<data1(b1,1)){

double proratio=0;


// the get the propose infection time
// check if the individual need to update the infection time
if (data1(b1,5+5*member)==1){
double prob[int(data1(b1,3))];
double totalprob=0;
for (b2=data1(b1,3)-1;b2>data1(b1,2)-1;--b2){
prob[b2]=0;
}
// have symptom
if ((data(b1,5+5*member+2)==1)&&(data(b1,5+5*member)==1)){
for (b2=19;b2>=0;--b2){
if (sym(b1,20*member+b2)!=-1){
prob[sym(b1,20*member+b2)-1]=1; //ILI(sym(b1,20*member+b2)-1,data1(b1,46));
totalprob+=prob[sym(b1,20*member+b2)-1];
}
}
}
// need to loop
else{
for (b2=sym(b1,20*member+1);b2>sym(b1,20*member);--b2){
prob[b2-1]=1; //ILI(b2-1,data1(b1,46));
totalprob+=prob[b2-1];
}
}


// here propose the infection time

double gen=((double)rand()/(RAND_MAX));
gen*=totalprob;
for (b2=data1(b1,3)-1;b2>data1(b1,2)-1;--b2){
gen-=prob[b2];
if (gen<0){
data1pro(b1,5+5*member+1)=b2+1;
// break out from the loop 
break;
}
}

//proratio+=log(ILI(data1pro(b1,5+5*member+1)-1,data1(b1,46)))-log(ILI(data1(b1,5+5*member+1)-1,data1(b1,46)));

}

// further add one more step to update symptom status 



// baseline AT update		
// here the proposal distribution based on the P(baseline) to increase the acceptance 
// then the proposal and likelihood will cancel out	
if (data(b1,5+5*member+4)==-1){	
double titerlevel1=((double)rand()/(RAND_MAX));
for (b3=9;b3>=0;--b3){
titerlevel1-=para2[b3+10*(data1(b1,5+5*member+3)>=18)+20*data1(b1,45)];
if (titerlevel1<0){
data1pro(b1,5+5*member+4)=b3;
// break out from the loop 
break;
}
}
}




// here compute the likelihood for propose
// first level is the symptom, it is always fixed

// second level
// it is about baseline AT only
// everything is gibbs sampler, not need this level

// third level

for (b3=data1pro(b1,1)-1;b3>=0;--b3){

loglik3pro(b1,2*b3)=0;
loglik3pro(b1,2*b3+1)=0;

// first generate the sus parameber
double sus;
sus=exp(para[33+data1(b1,45)]*(data1pro(b1,5+b3*5+4))+para[17+2*data1pro(b1,45)]*(data1pro(b1,5+b3*5+3)<18)+para[18+2*data1pro(b1,45)]*(data1pro(b1,5+b3*5+3)>50));



// the final date for contribution from non-infection
int finaltime=data1pro(b1,3)+1;
if (data1pro(b1,5+5*b3)==1){
finaltime=data1pro(b1,5+5*b3+1);	
}

double h[finaltime];
// fill the community risk
for (b2=finaltime;b2>data1pro(b1,2);--b2){
h[b2-1]=ILI(b2-1,data1pro(b1,46))*para[ (4+1*(b2>509))*(data1pro(b1,45)==0) + (5+data1pro(b1,45))*(data1pro(b1,45)>0)];	
}

for (b4=data1pro(b1,1)-1;b4>=0;--b4){
if (b4!=b3){
if (data1pro(b1,5+b4*5+1)!=-1){
for (b5=9;b5>=0;--b5){
if (data1pro(b1,5+b4*5+1)+b5+1<=finaltime){
double hrisk=0;
hrisk=para[11+data1pro(b1,45)]*exp(para[29]*(data1pro(b1,5+b4*5+2)==0)); 
h[data1pro(b1,5+b4*5+1)+b5]+=hrisk*SI[b5];
}
}
}
}	
}

for (b2=finaltime-1;b2>data1pro(b1,2);--b2){
loglik3pro(b1,2*b3)-=h[b2-1]*sus;	
}
if (data1pro(b1,5+5*b3)==1){
loglik3pro(b1,2*b3+1)+=log(1-exp(-h[finaltime-1]*sus));	
}

}


// here do the metropolis hasting update
double liknew=0;
double likold=0;
// don't add level1, it is always fixed
// don't add level2, beacuse using gibbs sampler
for (b2=15;b2>=0;--b2){
liknew+=loglik3pro(b1,b2);
likold+=loglik3(b1,b2);	
}


double loglikratio=liknew-likold;
double accept_pro=pow(exp(1),loglikratio-proratio);
mcmcrecord(b1,1)=accept_pro;
mcmcrecord(b1,2)=loglikratio;	
mcmcrecord(b1,3)=proratio;
if (gen_binom(accept_pro)){
mcmcrecord(b1,0)=1;	
// if accept, make the out to the same as the proposal
for (b2=5+5*member+4;b2>=5+5*member;--b2){
data1out(b1,b2)=data1pro(b1,b2);
}
for (b2=15;b2>=0;--b2){
loglik3out(b1,b2)=loglik3pro(b1,b2);	
}
}
else{
mcmcrecord(b1,0)=-1;	
}

}


}
}
};


//########################################################################################################################################
// function to update infection time, baseline AT titer
// but not the infection status
// [[Rcpp::export]]
List all_update(IntegerMatrix data1,	
IntegerMatrix data,	
IntegerMatrix sym,
NumericMatrix ILI,	
NumericVector para,
NumericVector para2,
NumericVector SI,
int member,
NumericMatrix loglik1,
NumericMatrix loglik2,
NumericMatrix loglik3){

IntegerMatrix data1pro(clone(data1));
IntegerMatrix data1out(clone(data1));
NumericMatrix loglik1pro(clone(loglik1));
NumericMatrix loglik2pro(clone(loglik2));
NumericMatrix loglik3pro(clone(loglik3));
NumericMatrix loglik1out(clone(loglik1));
NumericMatrix loglik2out(clone(loglik2));
NumericMatrix loglik3out(clone(loglik3));
// 1.accept/reject
NumericMatrix mcmcrecord(data1.nrow(),10);
NumericMatrix temprecord(data1.nrow(),10);

int b1;


// call parallel program
AllUpdate allupdate(data1out,data1pro,loglik1out,loglik2out,loglik3out,loglik1pro,loglik2pro,loglik3pro,mcmcrecord,data1,data,sym,ILI,para,para2,SI,member,loglik1,loglik2,loglik3,temprecord);
// call parallelFor to do the work
parallelFor(0,data1.nrow(),allupdate);


double a1=0;
double a2=0;
for (b1=mcmcrecord.nrow()-1;b1>=0;--b1){
if (mcmcrecord(b1,0)==1){
++a1;
}
if (mcmcrecord(b1,0)!=0){
++a2;	
}
}


return List::create(_[""]=data1out,
_[""]=loglik1out,
_[""]=loglik2out,
_[""]=loglik3out,
_[""]=a1/a2,
_[""]=mcmcrecord,
_[""]=data1pro,
_[""]=loglik1pro,
_[""]=loglik2pro,
_[""]=loglik3pro,
_[""]=temprecord);
}



//########################################################################################################################################
// function to add infection for reversible jump MCMC
// [[Rcpp::export]]
List add_remove_infection(IntegerMatrix data1,	
IntegerMatrix data,
IntegerMatrix sym,
NumericMatrix ILI,	
NumericVector para,
NumericVector para2,
NumericVector SI,
NumericMatrix loglik1,
NumericMatrix loglik2,
NumericMatrix loglik3){

IntegerMatrix data1pro(clone(data1));
IntegerMatrix data1out(clone(data1));
NumericMatrix loglik1pro(clone(loglik1));
NumericMatrix loglik2pro(clone(loglik2));
NumericMatrix loglik3pro(clone(loglik3));
NumericMatrix loglik1out(clone(loglik1));
NumericMatrix loglik2out(clone(loglik2));
NumericMatrix loglik3out(clone(loglik3));
// 1.accept/reject
NumericMatrix mcmcrecord(data1.nrow(),10);
NumericMatrix temprecord(1,10);

int b1;
int b2;
int b3;
int b4;   
int b5;



// first compute the number to add or delete
int numberofinfect=0;
int numberofall=0;
for (b1=data1.nrow()-1;b1>=0;--b1){
for (b2=data1(b1,1)-1;b2>=0;--b2){
if (data(b1,5+5*b2)==-1){
++numberofall;	
if (data1(b1,5+5*b2)==1){
++numberofinfect;
}
}
}
}

temprecord(0,0)=numberofinfect;
temprecord(0,1)=numberofall;


// here to do the add/delete step
int add=gen_binom(0.5);
int select=0;
double proratio=0;
int finalaccept=0;
int hhid=9999;
int member=9999;
temprecord(0,2)=add+1000000;
//######################################################################################################################################################################################################
// add infection
if (add){
if (numberofall-numberofinfect>0){
// first get the random number
select=rand()%(numberofall-numberofinfect);
// here get the subject and strain
// use hhid and member to indicate the subject
for (b1=data1.nrow()-1;b1>=0;--b1){
for (b2=data1(b1,1)-1;b2>=0;--b2){
if ((data(b1,5+5*b2)==-1)&&(data1(b1,5+5*b2)==0)){
if (select==0){
hhid=b1;
member=b2;
goto label1;
}
--select;
}
}
}

label1:

//##################################################################
// change infection status
data1pro(hhid,5+5*member)=1;
data1pro(hhid,5+5*member+2)=gen_binom(para[0+1*(data1pro(hhid,5+5*member+3)>=18)+2*data1pro(hhid,46)]);
// propose infection time
// the get the propose infection time
double prob[int(data1(hhid,3))];
double totalprob=0;
for (b2=data1(hhid,3)-1;b2>data1(hhid,2)-1;--b2){
prob[b2]=0;
}

for (b2=sym(hhid,20*member+1);b2>sym(hhid,20*member);--b2){
prob[b2-1]=1; //ILI(b2-1,data1(b1,46));
totalprob+=prob[b2-1];
}



// here propose the infection time
double gen=((double)rand()/(RAND_MAX));
gen*=totalprob;
for (b2=data1(hhid,3)-1;b2>data1(hhid,2)-1;--b2){
gen-=prob[b2];
if (gen<0){
data1pro(hhid,5+5*member+1)=b2+1;
// break out from the loop 
break;
}
}

proratio+=(log(1)-log(totalprob));


//##################################################################
// baseline AT update		
// here the proposal distribution based on the P(baseline) to increase the acceptance 
// then the proposal and likelihood will cancel out	
if (data(hhid,5+5*member+4)==-1){	
double titerlevel1=((double)rand()/(RAND_MAX));
for (b3=9;b3>=0;--b3){
titerlevel1-=para2[b3+10*(data1(hhid,5+5*member+3)>=18)+20*data1(hhid,45)];
if (titerlevel1<0){
data1pro(hhid,5+5*member+4)=b3;
// break out from the loop 
break;
}
}
}

//#############################################################################################################################################
// here compute the likelihood for propose
// first level is the symptom
// need to update because the probability of symptom depends on disease status

//double symprob=para[0+1*(data1pro(hhid,5+5*member+3)>=18)+2*data1pro(hhid,46)];
//loglik1pro(hhid,member)=data1_sym_pro(hhid,5+5*member+2)*log(symprob)+(1-data1_sym_pro(hhid,5+5*member+2))*log(1-symprob);

// second level
// it is about baseline AT only
// everything is gibbs sampler, not need this level

// third level

for (b3=data1pro(hhid,1)-1;b3>=0;--b3){

loglik3pro(hhid,2*b3)=0;
loglik3pro(hhid,2*b3+1)=0;

// first generate the sus parameber
double sus;
sus=exp(para[33+data1(hhid,45)]*(data1pro(hhid,5+b3*5+4))+para[17+2*data1pro(hhid,45)]*(data1pro(hhid,5+b3*5+3)<18)+para[18+2*data1pro(hhid,45)]*(data1pro(hhid,5+b3*5+3)>50));

// the final date for contribution from non-infection
int finaltime=data1pro(hhid,3)+1;
if (data1pro(hhid,5+5*b3)==1){
finaltime=data1pro(hhid,5+5*b3+1);	
}

double h[finaltime];
// fill the community risk
for (b2=finaltime;b2>data1pro(hhid,2);--b2){
h[b2-1]=ILI(b2-1,data1pro(hhid,46))*para[ (4+1*(b2>509))*(data1pro(hhid,45)==0) + (5+data1pro(hhid,45))*(data1pro(hhid,45)>0)];	
}

for (b4=data1pro(hhid,1)-1;b4>=0;--b4){
if (b4!=b3){
if (data1pro(hhid,5+b4*5+1)!=-1){
for (b5=9;b5>=0;--b5){
if (data1pro(hhid,5+b4*5+1)+b5+1<=finaltime){
double hrisk=0;
hrisk=para[11+data1pro(hhid,45)]*exp(para[29]*(data1pro(hhid,5+b4*5+2)==0)); 
h[data1pro(hhid,5+b4*5+1)+b5]+=hrisk*SI[b5];
}
}
}
}	
}

for (b2=finaltime-1;b2>data1pro(hhid,2);--b2){
loglik3pro(hhid,2*b3)-=h[b2-1]*sus;	
}
if (data1pro(hhid,5+5*b3)==1){
loglik3pro(hhid,2*b3+1)+=log(1-exp(-h[finaltime-1]*sus));	
}

}

// here do the metropolis hasting update
double liknew=0; //loglik1pro(hhid,member);
double likold=0; //loglik1(hhid,member);
// don't add level1, it is gibbs sampler
// don't add level2, beacuse using gibbs sampler
for (b2=15;b2>=0;--b2){
liknew+=loglik3pro(hhid,b2);
likold+=loglik3(hhid,b2);	
}


double loglikratio=liknew-likold;
double numberratio=(numberofall-numberofinfect)/(numberofinfect+1.0);
double accept_pro=pow(exp(1),loglikratio-proratio)*numberratio;
mcmcrecord(hhid,1)=accept_pro;
mcmcrecord(hhid,2)=loglikratio;	
mcmcrecord(hhid,3)=proratio;
mcmcrecord(hhid,6)=numberratio;
if (gen_binom(accept_pro)){
finalaccept=1;	
mcmcrecord(hhid,0)=1;	
// if accept, make the out to the same as the proposal
for (b2=5+5*member+4;b2>=5+5*member;--b2){
data1out(hhid,b2)=data1pro(hhid,b2);
}
//loglik1out(hhid,member)=loglik1pro(hhid,member);
for (b2=15;b2>=0;--b2){
loglik3out(hhid,b2)=loglik3pro(hhid,b2);	
}

//loglik1out(hhid,member)=R::dbinom(data1out(hhid,5+5*member+2),1,para[0+1*(data1out(hhid,5+5*member+3)>=18)+2*data1out(hhid,46)],1);

//loglik2out(hhid,member)=log(para2[10*(data1out(hhid,5+member*5+3)>=18)+data1out(hhid,5+member*5+4)+20*data1out(b1,45)]);

}
else{
mcmcrecord(hhid,0)=-1;	
}


mcmcrecord(hhid,5)=data1pro(hhid,5+5*member+1);


}
}

//######################################################################################################################################################################################################
// remove infection
else{
if (numberofinfect>0){
// first get the random number
select=rand()%(numberofinfect);
// here get the subject 
// use hhid and member
for (b1=data1.nrow()-1;b1>=0;--b1){
for (b2=data1(b1,1)-1;b2>=0;--b2){
if ((data(b1,5+5*b2)==-1)&&(data1(b1,5+5*b2)==1)){
if (select==0){
hhid=b1;
member=b2;
goto label2;
}
--select;
}
}
}

label2:

// here change the infection status
data1pro(hhid,5+5*member)=0;
data1pro(hhid,5+5*member+1)=-1;
data1pro(hhid,5+5*member+2)=0;
//##################################################################
// infection time

double prob[int(data1(hhid,3))];
double totalprob=0;
for (b2=data1(hhid,3)-1;b2>data1(hhid,2)-1;--b2){
prob[b2]=0;
}

for (b2=sym(hhid,20*member+1);b2>sym(hhid,20*member);--b2){
prob[b2-1]=1; //ILI(b2-1,data1(b1,46));
totalprob+=prob[b2-1];
}



// here need this to compute the proposal ratio

proratio-=(log(1)-log(totalprob));

//##################################################################
// baseline AT update		
// here the proposal distribution based on the P(baseline) to increase the acceptance 
// then the proposal and likelihood will cancel out	
if (data(hhid,5+5*member+4)==-1){	
double titerlevel1=((double)rand()/(RAND_MAX));
for (b3=9;b3>=0;--b3){
titerlevel1-=para2[b3+10*(data1(hhid,5+5*member+3)>=18)+20*data1(hhid,45)];
if (titerlevel1<0){
data1pro(hhid,5+5*member+4)=b3;
// break out from the loop 
break;
}
}
}




//#############################################################################################################################################
// here compute the likelihood for propose
// first level is the symptom
// need to update because the probability of symptom depends on disease status

//double symprob=para[33+1*(data1pro(hhid,5+5*member+3)>=18)];
//loglik1pro(hhid,member)=data1pro(hhid,5+5*member+2)*log(symprob)+(1-data1pro(hhid,5+5*member+2))*log(1-symprob);

// second level
// it is about baseline AT only
// everything is gibbs sampler, not need this level

// third level

for (b3=data1pro(hhid,1)-1;b3>=0;--b3){

loglik3pro(hhid,2*b3)=0;
loglik3pro(hhid,2*b3+1)=0;

// first generate the sus parameber
double sus;
sus=exp(para[33+data1(hhid,45)]*(data1pro(hhid,5+b3*5+4))+para[17+2*data1pro(hhid,45)]*(data1pro(hhid,5+b3*5+3)<18)+para[18+2*data1pro(hhid,45)]*(data1pro(hhid,5+b3*5+3)>50));

// the final date for contribution from non-infection
int finaltime=data1pro(hhid,3)+1;
if (data1pro(hhid,5+5*b3)==1){
finaltime=data1pro(hhid,5+5*b3+1);	
}

double h[finaltime];
// fill the community risk
for (b2=finaltime;b2>data1pro(hhid,2);--b2){
h[b2-1]=ILI(b2-1,data1pro(hhid,46))*para[ (4+1*(b2>509))*(data1pro(hhid,45)==0) + (5+data1pro(hhid,45))*(data1pro(hhid,45)>0) ];	
}

for (b4=data1pro(hhid,1)-1;b4>=0;--b4){
if (b4!=b3){
if (data1pro(hhid,5+b4*5+1)!=-1){
for (b5=9;b5>=0;--b5){
if (data1pro(hhid,5+b4*5+1)+b5+1<=finaltime){
double hrisk=0;
hrisk=para[11+data1pro(hhid,45)]*exp(para[29]*(data1pro(hhid,5+b4*5+2)==0)); 
h[data1pro(hhid,5+b4*5+1)+b5]+=hrisk*SI[b5];
}
}
}
}	
}

for (b2=finaltime-1;b2>data1pro(hhid,2);--b2){
loglik3pro(hhid,2*b3)-=h[b2-1]*sus;	
}
if (data1pro(hhid,5+5*b3)==1){
loglik3pro(hhid,2*b3+1)+=log(1-exp(-h[finaltime-1]*sus));	
}

}


// here do the metropolis hasting update
double liknew=0; //loglik1pro(hhid,member);
double likold=0; //loglik1(hhid,member);
// don't add level1, it is always fixed
// don't add level2, beacuse using gibbs sampler
for (b2=15;b2>=0;--b2){
liknew+=loglik3pro(hhid,b2);
likold+=loglik3(hhid,b2);	
}

double loglikratio=liknew-likold;
double numberratio=numberofinfect/(numberofall-numberofinfect+1.0);
double accept_pro=pow(exp(1),loglikratio-proratio)*numberratio;
mcmcrecord(hhid,1)=accept_pro;
mcmcrecord(hhid,2)=loglikratio;	
mcmcrecord(hhid,3)=proratio;
mcmcrecord(hhid,6)=numberratio;
if (gen_binom(accept_pro)){
finalaccept=1;	
mcmcrecord(hhid,0)=1;	
// if accept, make the out to the same as the proposal
for (b2=5+5*member+4;b2>=5+5*member;--b2){
data1out(hhid,b2)=data1pro(hhid,b2);
}
loglik1out(hhid,member)=0; //loglik1pro(hhid,member);
for (b2=15;b2>=0;--b2){
loglik3out(hhid,b2)=loglik3pro(hhid,b2);	
}

//loglik1out(hhid,member)=0;

//loglik2out(hhid,member)=log(para2[10*(data1out(hhid,5+member*5+3)>=18)+data1out(hhid,5+member*5+4)+20*data1out(b1,45)]);

}
else{
mcmcrecord(hhid,0)=-1;	
}

}
}


temprecord(0,5)=select+10000000;
temprecord(0,3)=hhid+10000000;
temprecord(0,4)=member+10000000;



return List::create(_[""]=data1out,	
_[""]=loglik1out,
_[""]=loglik2out,
_[""]=loglik3out,
_[""]=finalaccept,
_[""]=mcmcrecord,
_[""]=data1pro,
_[""]=loglik1pro,
_[""]=loglik2pro,
_[""]=loglik3pro,
_[""]=temprecord,
_[""]=numberofinfect,
_[""]=numberofall);
}












//##############################################################################################################################################
//##############################################################################################################################################
// function for mcmc
// [[Rcpp::export]]
List mcmc(IntegerMatrix data,
IntegerMatrix sym,
NumericMatrix ILI,	
int mcmc_n,             // length of mcmc stain
NumericVector int_para, // initial parameter
NumericVector int_para2,
NumericVector int_para3,
NumericVector move,     // which one should move in the model
NumericVector sigma,
NumericVector sigma3){            

// create the vector for use
int b0;
int b1;
int b2;
int b3;
int b4;
int moveindex;

// here declare the SI
NumericVector SI=serial_density(4.98,3.49);

// here data is the input that can not be changed
// data1 is the one with imputation
IntegerMatrix data1(clone(data));


// matrix to record LL
// need to set number of parameter here
NumericMatrix p_para(mcmc_n,int_para.length());
NumericMatrix p_para_r(mcmc_n,sum(move));
p_para(0,_)=int_para;
moveindex=sum(move)-1;
for (b1=int_para.length()-1;b1>=0;--b1){
if (move(b1)){
p_para_r(0,moveindex)=p_para(0,b1);
--moveindex;
}	
}

// for the second parameter vectors
NumericMatrix baselinecount(mcmc_n,int_para2.length());
for (b1=baselinecount.ncol()-1;b1>=0;--b1){
baselinecount(0,b1)=0;	
} 

for (b1=data1.nrow()-1;b1>=0;--b1){
for (b2=data1(b1,1)-1;b2>=0;--b2){	
if (data(b1,5+b2*5+4)!=-1){
++baselinecount(0,10*(data1(b1,5+5*b2+3)>=18)+floor(data1(b1,5+5*b2+4))+20*data1(b1,45));
}
}
}

NumericMatrix p_para2(mcmc_n,int_para2.length());
p_para2(0,_)=int_para2;

// for the third parameter vectors
NumericMatrix p_para3(mcmc_n,int_para3.length());
p_para3(0,_)=int_para3;



// here set the initial point for missing
int totalobs=0;

for (b1=data1.nrow()-1;b1>=0;--b1){
for (b2=data1(b1,1)-1;b2>=0;--b2){
++totalobs;	
// missing infection status
if (data(b1,5+5*b2)==-1){
data1(b1,5+5*b2)=1;	
data1(b1,5+5*b2+2)=gen_binom(0.5);
data1(b1,5+5*b2+1)=(sym(b1,20*b2)+sym(b1,20*b2+1))/2;
}
// missing infection time
if ((data(b1,5+5*b2)==1)&&(data(b1,5+5*b2+1)==-1)){
if (data(b1,5+5*b2+2)==1){
data1(b1,5+5*b2+1)=sym(b1,20*b2);
}
else{
data1(b1,5+5*b2+1)=(sym(b1,20*b2)+sym(b1,20*b2+1))/2;
}
}
// missing titer
if (data1(b1,5+5*b2+4)==-1){
data1(b1,5+5*b2+4)=0;	
}
}
}



// first row is the overall matrix, other three row is the indiviudal likelihood
NumericVector acceptrate(int_para.length());
NumericVector acceptrate3(int_para3.length());
NumericMatrix LL1(mcmc_n,4); // the original likelihood
NumericMatrix LL2(mcmc_n,int_para3.length()); // the likelihood for hyperparameter
NumericMatrix LL3(mcmc_n,4); // for the update except the infeciton status
NumericMatrix LL4(mcmc_n,4);
NumericMatrix LL5(mcmc_n,4);
NumericMatrix totalinfectionnumber(mcmc_n,6);
NumericMatrix updateacceptrate(mcmc_n,2);

IntegerMatrix infection_status_record(10000,totalobs);
//####################################################################################################################################
// initial step

//####################################################################################################################################
// compute likelihood


List loglikall=loglik(data1,data,ILI,p_para(0,_),p_para2(0,_),SI,1,1,1);
List loglikallpro;
NumericMatrix loglik1=loglikall(0);
NumericMatrix loglik2=loglikall(1);
NumericMatrix loglik3=loglikall(2);
NumericMatrix loglik1pro;
NumericMatrix loglik2pro;
NumericMatrix loglik3pro;

LL1(0,1)=sum(loglik1);
LL1(0,2)=sum(loglik2);
LL1(0,3)=sum(loglik3);
LL1(0,0)=LL1(0,1)+LL1(0,2)+LL1(0,3);

NumericVector temploglik(4);
NumericVector newloglik(4);
temploglik(0)=LL1(0,0)+prior_loglik(p_para(0,_));
temploglik(1)=LL1(0,1);
temploglik(2)=LL1(0,2);
temploglik(3)=LL1(0,3);

// here also need to fill the LL3
for (b1=11;b1>=0;--b1){	
LL2(0,b1)=log(tgamma(10*p_para3(0,b1)))-10*log(tgamma(p_para3(0,b1)));
for (b2=9;b2>=0;--b2){
LL2(0,b1)+=(p_para3(0,b1)-1)*log(p_para2(0,10*b1+b2));
}
}



double loglikeratio;
double accept_pro;
NumericVector pro_para(int_para.length());

// record total infection number
for (b1=data1.nrow()-1;b1>=0;--b1){
for (b2=data1(b1,1)-1;b2>=0;--b2){
if (data1(b1,5+5*b2)==1){
++totalinfectionnumber(0,data1(b1,45));	
}	
}
}

//####################################################################################################################################
// main mcmc step
NumericMatrix record(mcmc_n,15);

//####################################################################################################################################
for (b0=1;b0<mcmc_n;++b0){


// after 500 step, then set the sigma to be the empirical sigma
if ((b0>500)&&(b0%200==0)){
for (b1=int_para.length()-1;b1>=0;--b1){
if (move(b1)){	
NumericVector temp1(b0-1);
for (b2=b0-2;b2>=0;--b2){
temp1(b2)=p_para(b2,b1);	
}
sigma(b1)=sd(temp1);
// tuning
if (acceptrate(b1)<0.1){
sigma(b1)*=0.5;
}	
if ((acceptrate(b1)<0.15)&(acceptrate(b1)>0.1)){
sigma(b1)*=0.8;
}
if ((acceptrate(b1)<0.2)&(acceptrate(b1)>0.15)){
sigma(b1)*=0.95;
}
if ((acceptrate(b1)<0.4)&(acceptrate(b1)>0.3)){
sigma(b1)*=1.05;
}
if ((acceptrate(b1)<0.9)&(acceptrate(b1)>0.4)){
sigma(b1)*=1.2;
}
if (acceptrate(b1)>0.9){
sigma(b1)*=2;
}
}
}
// for sigma3

for (b1=int_para3.length()-1;b1>=0;--b1){
NumericVector temp1(b0-1);
for (b2=b0-2;b2>=0;--b2){
temp1(b2)=p_para3(b2,b1);	
}
sigma3(b1)=sd(temp1);
// tuning
if (acceptrate3(b1)<0.1){
sigma3(b1)*=0.5;
}	
if ((acceptrate3(b1)<0.15)&(acceptrate3(b1)>0.1)){
sigma3(b1)*=0.8;
}
if ((acceptrate3(b1)<0.2)&(acceptrate3(b1)>0.15)){
sigma3(b1)*=0.95;
}
if ((acceptrate3(b1)<0.4)&(acceptrate3(b1)>0.3)){
sigma3(b1)*=1.05;
}
if ((acceptrate3(b1)<0.9)&(acceptrate3(b1)>0.4)){
sigma3(b1)*=1.2;
}
if (acceptrate3(b1)>0.9){
sigma3(b1)*=2;
}
}

}


// metorpolis-hasing update on parameter
for (b1=0;b1<int_para.length();++b1){
if (move(b1)){
int level=3;
if (b1<=3){ 
level=1;
}

// no level 2 here, they are both for the baseline titer distribution
pro_para=p_para(b0-1,_);
for (b2=b1-1;b2>=0;--b2){
pro_para(b2)=p_para(b0,b2);	
}
pro_para(b1)+=rnorm(0.0,sigma(b1));
newloglik(0)=prior_loglik(pro_para);
if (newloglik(0)> -9999999){
// level 3 
if (level==3){
loglikallpro=loglik(data1,data,ILI,pro_para,p_para2(b0-1,_),SI,0,0,1);
NumericMatrix tempoutput=loglikallpro(2);
loglik3pro=clone(tempoutput);
newloglik(1)=temploglik(1);
newloglik(2)=temploglik(2);
newloglik(3)=sum(loglik3pro);
}
if (level==1){ // level1
loglikallpro=loglik(data1,data,ILI,pro_para,p_para2(b0-1,_),SI,1,0,0);
NumericMatrix tempoutput=loglikallpro(0);
loglik1pro=clone(tempoutput);
newloglik(1)=sum(loglik1pro);
newloglik(2)=temploglik(2);
newloglik(3)=temploglik(3);
}
newloglik(0)+=newloglik(1)+newloglik(2)+newloglik(3);
loglikeratio=newloglik(0)-temploglik(0);
accept_pro=pow(exp(1),loglikeratio);
if (b1==1){
record(b0,0)=loglikeratio;
record(b0,1)=newloglik(0);	
record(b0,2)=newloglik(1);	
record(b0,3)=newloglik(2);	
record(b0,4)=newloglik(3);	
record(b0,5)=temploglik(0);	
record(b0,6)=temploglik(1);	
record(b0,7)=temploglik(2);	
record(b0,8)=temploglik(3);		
}
}
else{
accept_pro=0;	
}
if(gen_binom(accept_pro)){
if (level==1){
loglik1=clone(loglik1pro);	
temploglik(1)=newloglik(1);
}
if (level==3){
loglik3=clone(loglik3pro);		
temploglik(3)=newloglik(3);	
}
p_para(b0,b1)=pro_para(b1);
temploglik(0)=newloglik(0);
acceptrate(b1)*=(b0-1);
acceptrate(b1)+=1;
acceptrate(b1)/=b0;
}
else{
p_para(b0,b1)=p_para(b0-1,b1);
acceptrate(b1)*=(b0-1);
acceptrate(b1)/=b0;
}
}
else {
p_para(b0,b1)=p_para(b0-1,b1);
}
}

LL1(b0,0)=temploglik(0)-prior_loglik(p_para(b0,_));
LL1(b0,1)=temploglik(1);
LL1(b0,2)=temploglik(2);
LL1(b0,3)=temploglik(3);


// here to update p_para2


NumericVector tempcount(int_para3.length());
for (b1=int_para3.length()-1;b1>=0;--b1){
tempcount(b1)=0;	
}
for (b1=baselinecount.ncol()-1;b1>=0;--b1){
p_para2(b0,b1)=R::rgamma(baselinecount(0,b1)+p_para3(b0-1,b1/10),1.0);
tempcount(b1/10)+=p_para2(b0,b1);
}
for (b1=baselinecount.ncol()-1;b1>=0;--b1){
p_para2(b0,b1)/=tempcount(b1/10);
}

// here need to update the likelihood
loglikallpro=loglik(data1,data,ILI,p_para(b0,_),p_para2(b0,_),SI,0,1,0);
NumericMatrix tempoutput=loglikallpro(1);
loglik2=clone(tempoutput);
temploglik(2)=sum(loglik2);
temploglik(0)=prior_loglik(p_para(b0,_))+temploglik(1)+temploglik(2)+temploglik(3);

// here to update p_para3
// need to write the dirichlet likelihood here
// here conduct metropolis hasting
//p_para3(b0,_)=int_para3;

double hyperoldlik=0;
double hypernewlik=0;

for (b1=int_para3.length()-1;b1>=0;--b1){
p_para3(b0,b1)=p_para3(b0-1,b1)+rnorm(0.0,sigma3(b1));
hyperoldlik=log(tgamma(10*p_para3(b0-1,b1)))-10*log(tgamma(p_para3(b0-1,b1)));
for (b2=9;b2>=0;--b2){
hyperoldlik+=(p_para3(b0-1,b1)-1)*log(p_para2(b0,10*b1+b2));
}
if (p_para3(b0,b1)<0){
accept_pro=0;
}
else{
hypernewlik=log(tgamma(10*p_para3(b0,b1)))-10*log(tgamma(p_para3(b0,b1)));
for (b2=9;b2>=0;--b2){
hypernewlik+=(p_para3(b0,b1)-1)*log(p_para2(b0,10*b1+b2));
}
loglikeratio=hypernewlik-hyperoldlik;
accept_pro=pow(exp(1),loglikeratio);
}
// here do the metropolis hasting
// accept
if(gen_binom(accept_pro)){
acceptrate3(b1)*=(b0-1);
acceptrate3(b1)+=1;
acceptrate3(b1)/=b0;
LL2(b0,b1)=hypernewlik;
}
else{
LL2(b0,b1)=hyperoldlik;
p_para3(b0,b1)=p_para3(b0-1,b1);
acceptrate3(b1)*=(b0-1);
acceptrate3(b1)/=b0;
}
} 



for (b1=7;b1>=0;--b1){
// update the boosting waning parameter without changing infection status
List allupdate=all_update(data1,data,sym,ILI,p_para(b0,_),p_para2(b0,_),SI,b1,loglik1,loglik2,loglik3);
IntegerMatrix tempoutput1=allupdate(0);
data1=clone(tempoutput1);
NumericMatrix tempoutput3=allupdate(1);
loglik1=clone(tempoutput3);
NumericMatrix tempoutput4=allupdate(2);
loglik2=clone(tempoutput4);
NumericMatrix tempoutput5=allupdate(3);
loglik3=clone(tempoutput5);
updateacceptrate(b0,0)=allupdate(4);
}

// update the impute likelihood
LL3(b0,1)=sum(loglik1);
LL3(b0,2)=sum(loglik2);
LL3(b0,3)=sum(loglik3);
LL3(b0,0)=LL3(b0,1)+LL3(b0,2)+LL3(b0,3);

temploglik(0)=LL3(b0,0)+prior_loglik(p_para(b0,_));
temploglik(1)=LL3(b0,1);
temploglik(2)=LL3(b0,2);
temploglik(3)=LL3(b0,3);


// add/remove infection step
for (b1=8;b1>=0;--b1){
List addremoveinfection=add_remove_infection(data1,data,sym,ILI,p_para(b0,_),p_para2(b0,_),SI,loglik1,loglik2,loglik3);
IntegerMatrix tempoutput11=addremoveinfection(0);
data1=clone(tempoutput11);
NumericMatrix tempoutput13=addremoveinfection(1);
loglik1=clone(tempoutput13);
NumericMatrix tempoutput14=addremoveinfection(2);
loglik2=clone(tempoutput14);
NumericMatrix tempoutput15=addremoveinfection(3);
loglik3=clone(tempoutput15);
}

List addremoveinfection=add_remove_infection(data1,data,sym,ILI,p_para(b0,_),p_para2(b0,_),SI,loglik1,loglik2,loglik3);
IntegerMatrix tempoutput11=addremoveinfection(0);
data1=clone(tempoutput11);
NumericMatrix tempoutput13=addremoveinfection(1);
loglik1=clone(tempoutput13);
NumericMatrix tempoutput14=addremoveinfection(2);
loglik2=clone(tempoutput14);
NumericMatrix tempoutput15=addremoveinfection(3);
loglik3=clone(tempoutput15);

updateacceptrate(b0,1)=addremoveinfection(4);


// update the impute likelihood
LL4(b0,1)=sum(loglik1);
LL4(b0,2)=sum(loglik2);
LL4(b0,3)=sum(loglik3);
LL4(b0,0)=LL4(b0,1)+LL4(b0,2)+LL4(b0,3);

temploglik(0)=LL4(b0,0)+prior_loglik(p_para(b0,_));
temploglik(1)=LL4(b0,1);
temploglik(2)=LL4(b0,2);
temploglik(3)=LL4(b0,3);



//for (b1=data11.nrow()-1;b1>=0;--b1){
// record infection status	
//impute_record_infstatus1(b0,b1)=data21(b1,3);
// record infection time	
//impute_record_inftime1(b0,b1)=data21(b1,4);
// here record the waning rate
//impute_record_waning1(b0,b1)=data21(b1,6);
// here record the boosting
//impute_record_boosting1(b0,b1)=data21(b1,5);
// here record the baseline AT
//impute_record_titer1(b0,b1)=data11(b1,8);
//}

//totalinfectionnumber(b0,0)=sum(data21(_,3));


// move the matirx to another matrix to store the parameter and compute the correlation matrix
moveindex=sum(move)-1;
for (b1=int_para.length()-1;b1>=0;--b1){
if (move(b1)){
p_para_r(b0,moveindex)=p_para(b0,b1);
--moveindex;
}	
}

// record total infection number
for (b1=data1.nrow()-1;b1>=0;--b1){
for (b2=data1(b1,1)-1;b2>=0;--b2){
if (data1(b1,5+5*b2)==1){
++totalinfectionnumber(b0,data1(b1,45));
}	
}
}


if ((b0>50000)&&(b0%5==4)){
int currentindex=totalobs-1;
for (b1=data1.nrow()-1;b1>=0;--b1){
for (b2=data1(b1,1)-1;b2>=0;--b2){
infection_status_record((b0-49999)/5-1,currentindex)=data1(b1,5+5*b2);
--currentindex;
}
}
}

if (b0%1000==0){
Rcout << b0 << std::endl;
}

}


return List::create(_[""]=p_para,
_[""]=p_para2,
_[""]=p_para3,
_[""]=LL1,
_[""]=LL2,
_[""]=LL3,
_[""]=LL4,
_[""]=updateacceptrate,
_[""]=totalinfectionnumber,
_[""]=data1,
_[""]=infection_status_record);
} 





//##############################################################################################################################################
//##############################################################################################################################################
// function for compute hh dist
// [[Rcpp::export]]
List pred_obs(IntegerMatrix data,
IntegerMatrix sym,
NumericMatrix ILI,
NumericMatrix para,
NumericMatrix para2,
NumericVector miss_ind,
double aviprob){

int sep1=5;
int sep2=5;
int b0;
int b1;
int b2;
int index;

// general infection number of 6 seasons
NumericMatrix hh1(data.nrow(),para.nrow()+1);

NumericMatrix hh1b(63*6,para.nrow()+1);

// by symptomatic and asymptomatic
//symptomatic
NumericMatrix hh2(data.nrow(),para.nrow()+1);
NumericMatrix hh2b(63,para.nrow()+1);
//asymptomatic
NumericMatrix hh3(data.nrow(),para.nrow()+1);
NumericMatrix hh3b(63,para.nrow()+1);

//
for (b1=data.nrow()-1;b1>=0;--b1){
for (b2=data(b1,1)-1;b2>=0;--b2){
if (data(b1,b2*sep2+sep1)==1){
++hh1(b1,0);	
if (data(b1,b2*sep2+sep1+2)==1){
++hh2(b1,0);
}
else{
++hh3(b1,0);	
}
}	
}
++hh1b((data(b1,1)-2)*9+hh1(b1,0)+63*data(b1,45),0);
++hh2b((data(b1,1)-2)*9+hh2(b1,0),0);	
++hh3b((data(b1,1)-2)*9+hh3(b1,0),0);	
}

for (b0=para.nrow()-1;b0>=0;--b0){

if (b0%10==0){
Rcout << b0 << std::endl;
}

List datasim=sim_data(data,sym,ILI,para(b0,_),para2(b0,_),miss_ind,aviprob);	
IntegerMatrix data11=datasim(2);
for (b1=data.nrow()-1;b1>=0;--b1){
for (b2=data(b1,1)-1;b2>=0;--b2){
if ((data11(b1,b2*sep2+sep1)==1)&&(data(b1,b2*sep2+sep1)!=-1)){
++hh1(b1,b0+1);	
if (data(b1,b2*sep2+sep1+2)==1){
++hh2(b1,b0+1);
}
else{
++hh3(b1,b0+1);	
}
}	
}
++hh1b((data(b1,1)-2)*9+hh1(b1,b0+1)+63*data(b1,45),b0+1);	
++hh2b((data(b1,1)-2)*9+hh2(b1,b0+1),b0+1);	
++hh3b((data(b1,1)-2)*9+hh3(b1,b0+1),b0+1);	
}

}

return List::create(_[""]=hh1b,
_[""]=hh2b,
_[""]=hh3b,
_[""]=hh1,
_[""]=hh2,
_[""]=hh3);
} 
 



















//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel for doing simulation
struct CountMatch:public Worker{
// source vector
RMatrix<int> data;
RMatrix<int> data1;
RMatrix<double> ILI;
RVector<double> para;
RVector<double> para2;
RVector<double> SI;
RMatrix<double> countmatch;
int simtime;
// destination vector
// initialize with source and destination
CountMatch(IntegerMatrix data,
IntegerMatrix data1,
NumericMatrix ILI,
NumericVector para,
NumericVector para2,
NumericVector SI,
NumericMatrix countmatch,
int simtime) 
:data(data),data1(data1),ILI(ILI),para(para),para2(para2),SI(SI),countmatch(countmatch),simtime(simtime){}
void operator()(std::size_t begin, std::size_t end) {

// section to write the parallel version
// functor (pass input and output matrixes)
for (unsigned int b1=begin;b1<end;++b1){
int b2;
int b3;
int b4;
int b5;
int b6;

// unchanged sus
double sus[int(data1(b1,1))];
for (b3=data1(b1,1)-1;b3>=0;--b3){
sus[b3]=exp(para[17+2*data1(b1,45)]*(data1(b1,5+b3*5+3)<18)+para[18+2*data1(b1,45)]*(data1(b1,5+b3*5+3)>50));
if (data(b1,5+b3*5+4)!=-1){
sus[b3]*=exp(para[33+data1(b1,45)]*(data1(b1,5+b3*5+4)));
}
}

for (b6=simtime-1;b6>=0;--b6){

// here clean out the infection status, and let them to be missing
for (b2=data1(b1,1)-1;b2>=0;--b2){
data1(b1,5+b2*5+0)=0;
data1(b1,5+b2*5+1)=-1;
data1(b1,5+b2*5+2)=-1;
}	
// here generate the baseline titer level
// first select 0-9
for (b2=data1(b1,1)-1;b2>=0;--b2){
if (data(b1,5+b2*5+4)==-1){	
double titerlevel1=((double)rand()/(RAND_MAX));
for (b3=9;b3>=0;--b3){
titerlevel1-=para2[b3+10*(data1(b1,5+b2*5+3)>=18)+20*data1(b1,45)];
if (titerlevel1<0){
data1(b1,5+b2*5+4)=b3;
// break out from the loop 
break;
}
}
sus[b2]*=exp(para[33+data1(b1,45)]*(data1(b1,5+b2*5+4)));
}
}

// 499 is the change point
// b2 is time index
for (b2=data1(b1,2)+1;b2<=data1(b1,3);++b2){
// b3 is participant index
for (b3=data1(b1,1)-1;b3>=0;--b3){	
// at risk 	
if (data1(b1,5+b3*5)==0){ 
// community risk
double hazard1=ILI(b2-1,data1(b1,46))*para[4+data1(b1,45)]; //*pow(3,b2>509); //+3*(b2>509)
// household risk
for (b4=data1(b1,1)-1;b4>=0;--b4){
if (b4!=b3){
// need to with the range of serial interval to have contribution
if ((b2-data1(b1,5+b4*5+1)>0)&&(b2-data1(b1,5+b4*5+1)<=10)){	
// need to -1 beacuse the index is from 0 to 9
// transmissibility for asymptomatic vs symptomatic
hazard1+=para[11+data1(b1,45)]*SI[b2-data1(b1,5+b4*5+1)-1]*exp(para[29]*(data1(b1,5+b4*5+2)==0)); 
}
}
}

int inf=gen_binom(1-exp(-hazard1*sus[b3]));

if (inf==1){
data1(b1,5+5*b3)=1;
// infection time
data1(b1,5+5*b3+1)=b2;
// symptom
data1(b1,5+5*b3+2)=gen_binom(para[0+1*(data1(b1,5+5*b3+3)>=18)+2*data1(b1,46)]);
}

}
}
}

/*
// the loop for counting if match with the observation data
double match=1;
for (b2=data1(b1,1)-1;b2>=0;--b2){
if (data1(b1,5+5*b2)!=-1){	
if (data1(b1,5+5*b2)!=data(b1,5+5*b2)){
match*=0.001;
}
else{
match*=0.999;	
}	
}
}
countmatch(b1,0)+=match;
*/


// the loop for counting infection
double match=1;
for (b2=data1(b1,1)-1;b2>=0;--b2){
if (data1(b1,5+5*b2)==1){	
++countmatch(b1,6);
++countmatch(b1,data(b1,45));
}
}


}



}
}
};



//########################################################################################################################################
//function to do simulation
// [[Rcpp::export]]
NumericMatrix countmatch(IntegerMatrix data,
IntegerMatrix sym,
NumericMatrix ILI,
NumericVector para,
NumericVector para2,
int simtime){
// clone the data first
IntegerMatrix data1(clone(data)); // output
NumericMatrix countmatch(data.nrow(),7);

// compute the serial_density to use
NumericVector SI=serial_density(4.98,3.49);


CountMatch simdata1(data,data1,ILI,para,para2,SI,countmatch,simtime);
// call parallelFor to do the work
parallelFor(0,data1.nrow(),simdata1);


return countmatch;
} 






//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel for doing simulation
struct CountMatch2:public Worker{
// source vector
RMatrix<int> data;
RMatrix<int> data1;
RMatrix<double> ILI;
RMatrix<double> para;
RMatrix<double> para2;
RVector<double> SI;
RMatrix<double> countmatch;
int simtime;
// destination vector
// initialize with source and destination
CountMatch2(IntegerMatrix data,
IntegerMatrix data1,
NumericMatrix ILI,
NumericMatrix para,
NumericMatrix para2,
NumericVector SI,
NumericMatrix countmatch,
int simtime) 
:data(data),data1(data1),ILI(ILI),para(para),para2(para2),SI(SI),countmatch(countmatch),simtime(simtime){}
void operator()(std::size_t begin, std::size_t end) {

// section to write the parallel version
// functor (pass input and output matrixes)
for (unsigned int b1=begin;b1<end;++b1){
int b2;
int b3;
int b4;
int b5;
int b6;
int b7;

// first based on the paravalue compute the susceptibility

double agesus[12];
for (b2=11;b2>=0;--b2){
agesus[b2]=exp(para(b1,17+b2));	
}
double hisus[6][10];
for (b2=5;b2>=0;--b2){
for (b3=9;b3>=0;--b3){
hisus[b2][b3]=exp(para(b1,33+b2)*b3);	
}	
}

double relinf=exp(para(b1,29));

for (b7=data.nrow()-1;b7>=0;--b7){

// unchanged sus
double sus[int(data1(b7,1))];
for (b3=data1(b7,1)-1;b3>=0;--b3){
sus[b3]=pow(agesus[0+2*data1(b7,45)],(data1(b7,5+b3*5+3)<18))*pow(agesus[1+2*data1(b7,45)],(data1(b7,5+b3*5+3)>50));
if (data(b7,5+b3*5+4)!=-1){
sus[b3]*=hisus[data1(b7,45)][data1(b7,5+b3*5+4)];
}
}

for (b6=simtime-1;b6>=0;--b6){

// here clean out the infection status, and let them to be missing
for (b2=data1(b7,1)-1;b2>=0;--b2){
data1(b7,5+b2*5+0)=0;
data1(b7,5+b2*5+1)=-1;
data1(b7,5+b2*5+2)=-1;
}	

// here generate the baseline titer level
// first select 0-9
for (b2=data1(b7,1)-1;b2>=0;--b2){
if (data(b7,5+b2*5+4)==-1){	
double titerlevel1=((double)rand()/(RAND_MAX));
for (b3=9;b3>=0;--b3){
titerlevel1-=para2(b1,b3+10*(data1(b7,5+b2*5+3)>=18)+20*data1(b7,45));
if (titerlevel1<0){
data1(b7,5+b2*5+4)=b3;
// break out from the loop 
break;
}
}
sus[b2]*=hisus[data1(b7,45)][data1(b7,5+b2*5+4)];
}
}

// 499 is the change point
// b2 is time index
for (b2=data1(b7,2)+1;b2<=data1(b7,3);++b2){
// b3 is participant index
for (b3=data1(b7,1)-1;b3>=0;--b3){	
// at risk 	
if (data1(b7,5+b3*5)==0){ 
// community risk
double hazard1=ILI(b2-1,data1(b7,46))*para(b1,4+data1(b7,45)); //*pow(3,b2>509); //+3*(b2>509)
// household risk
for (b4=data1(b7,1)-1;b4>=0;--b4){
if (b4!=b3){
// need to with the range of serial interval to have contribution
if ((b2-data1(b7,5+b4*5+1)>0)&&(b2-data1(b7,5+b4*5+1)<=10)){	
// need to -1 beacuse the index is from 0 to 9
// transmissibility for asymptomatic vs symptomatic
hazard1+=para(b1,11+data1(b7,45))*SI[b2-data1(b7,5+b4*5+1)-1]*pow(relinf,(data1(b7,5+b4*5+2)==0)); 
}
}
}

int inf=gen_binom(1-exp(-hazard1*sus[b3]));

if (inf==1){
data1(b7,5+5*b3)=1;
// infection time
data1(b7,5+5*b3+1)=b2;
// symptom
data1(b7,5+5*b3+2)=gen_binom(para(b1,0+1*(data1(b7,5+5*b3+3)>=18)+2*data1(b7,46)));
}

}
}
}

double match=1;
for (b2=data1(b7,1)-1;b2>=0;--b2){
if (data1(b7,5+5*b2)!=-1){	
if (data1(b7,5+5*b2)!=data(b7,5+5*b2)){
match*=0.001;
}
else{
match*=0.999;	
}	
}
}
countmatch(b1,b7)+=match;


}
}


}
}
};



//########################################################################################################################################
//function to do simulation
// [[Rcpp::export]]
NumericMatrix countmatch2(IntegerMatrix data,
IntegerMatrix sym,
NumericMatrix ILI,
NumericMatrix para,
NumericMatrix para2,
int simtime){
// clone the data first
IntegerMatrix data1(clone(data)); // output
NumericMatrix countmatch(para.nrow(),data.nrow());

// compute the serial_density to use
NumericVector SI=serial_density(4.98,3.49);


CountMatch2 simdata1(data,data1,ILI,para,para2,SI,countmatch,simtime);
// call parallelFor to do the work
parallelFor(0,para.nrow(),simdata1);



return countmatch;
} 


