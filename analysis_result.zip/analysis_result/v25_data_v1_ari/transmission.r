
rm(list = ls())

library(Rcpp)
library(RcppParallel)

Sys.setenv("PKG_CXXFLAGS"="-std=c++11")
########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
    y[i,1] <- mean(mcmc[,i])
    }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}


try(setwd("/Users/timtsang/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/realdata/v25_data_v1_ari"))
#setwd("Z:/kiddivax_transmission/asymptomatic/realdata/v16_data_v1_any")
try(setwd("C:/Users/user/SPH Dropbox/Tim Tsang/_influenza/kiddivax_transmission/asymptomatic/realdata/v25_data_v1_ari"))

#for (iiii in 1:20){
########################################################################################################################################################################
data <- read.csv("2022_10_22_data_v1_ari.csv")
data[is.na(data)] <- -1
sym <- read.csv("2022_10_22_sym_v1_ari.csv")

########################################################################################################################################################################

ILI <- read.csv("ILILAB_2019_04_25.csv",header=F)
ILI[ILI==0] <- 0.00000000001

## here also adjust the 14 day delay here
## here the proxy is starting from 2008/01/01, data is starting from 2008/07/01
ILI <- ILI[-c(1:(182-14)),]


## for parameter of SI
## assumed to be known and put in the code directly

## model parameter
## 1,2,3,4, the probability of symptom: h1, children and adults and h3, children and adults 
## 5-11: season 1-6
## 12-17: household transmission parameter for 6 season (can use 12,13 for h1 and h3 first)
## 18-19,20-21,22-23,24-25,26-27,28-29, age parameter for children and older adults.
## 30-33, transmissiliby for asymptomatic vs symptomatic: h1, children and adults, h3 children and adults (30,31, children , adults ).
## 34-39, HAI titer protection

### later add (those variance parameter)

## first create a function for simulation

int_para <-  c(rep(0.6,4),
               rep(0.1,7),
               rep(0.05,6),
               rep(c(0,0),6),
               rep(0,4),
               rep(0,6))


# children, adults
int_para2 <- c(0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005) 

#int_para <- as.vector(as.matrix(read.csv("para1.csv"))[,2] )
#int_para2 <- as.vector(as.matrix(read.csv("para2.csv"))[,2])
#for (i in 1:12){
#int_para2[10*(i-1)+1] <- 1- sum(int_para2[10*(i-1)+2:10])
#}



sourceCpp("transmission.cpp")

########################################################################################################################################################################
########### here is inputing the data
data <- as.matrix(data)
sym <- as.matrix(sym)
ILI <- as.matrix(ILI)
########################################################################################################################################################################

sum(data[,8]==0&data[,6]==1)
sym[data[,8]==0&data[,6]==1,1:2]

### in MCMC, need to chnage the level for para 34,35!!!!!!!!!!

t <- sim_data(data,sym,ILI,int_para,int_para2,c(1,1,1),0.6)

input1 <- t[[1]]
input2 <- t[[2]]
input1_full <- t[[3]]

table(data[,6+0:7*5]==-1)
table(input1[,6+0:7*5]==-1)
#input1[t[[4]][,1]==101,] -> bb
########################################################################################################################################################################
## here to set to real data
input1 <- data
input2 <- sym

########################################################################################################################################################################

SI <- serial_density(4.98,3.49)

########################################################################################################################################################################
## here is the testing session

# 


test <- loglik(input1_full,input1,ILI,int_para,int_para2,SI,1,1,1)
sum(test[[1]])+sum(test[[2]])+sum(test[[3]])

 sourceCpp("transmission.cpp")
 
 test2 <- all_update(input1_full,input1,input2,ILI,int_para,int_para2,SI,0,test[[1]],test[[2]],test[[3]])
 sum(test2[[2]])+sum(test2[[3]])+sum(test2[[4]])
 
 test3 <- loglik(test2[[1]],input1,ILI,int_para,int_para2,SI,1,1,1)
 sum(test3[[1]])+sum(test3[[2]])+sum(test3[[3]])

 sourceCpp("transmission.cpp")
 
 test <- loglik(input1_full,input1,ILI,int_para,int_para2,SI,1,1,1)
 sum(test[[1]])+sum(test[[2]])+sum(test[[3]])
 
 test2 <- add_remove_infection(input1_full,input1,input2,ILI,int_para,int_para2,SI,test[[1]],test[[2]],test[[3]])
 sum(test2[[2]])+sum(test2[[3]])+sum(test2[[4]])
 
 test3 <- loglik(test2[[1]],input1,ILI,int_para,int_para2,SI,1,1,1)
 sum(test3[[1]])+sum(test3[[2]])+sum(test3[[3]])

####################################################################################

sigma <- (abs(int_para)+0.1)/10
move <- rep(1,length(int_para))
move[c(3:4,7:11,13:17,19:29,31:39)] <- 0
para <- int_para
#move[5:39] <- 0

int_para3 <- rep(1,12)
sigma3 <- int_para3/10

para2 <- rep(0.1,120)


sourceCpp("transmission.cpp")

aaaaa1 <- Sys.time()
tt <- mcmc(input1,input2,ILI,100000,para,para2,int_para3,move,sigma,sigma3)
aaaaa2 <- Sys.time()
print(aaaaa2-aaaaa1)

sum(tt[[10]][,6]==1 & tt[[10]][,7]==-1)

#para_summary(tt[[2]],4,3,1)

#table(floor(tt[[8]][t[[2]][,9]!=-1&t[[1]][,3]<1,9]))/sum(table(floor(tt[[8]][t[[2]][,9]!=-1&t[[1]][,3]<1,9])))

#table(floor(tt[[8]][t[[1]][,3]<1,9]))/sum(table(floor(tt[[8]][t[[1]][,3]<1,9])))

test <- loglik(tt[[10]],input1,ILI,int_para,int_para2,SI,1,1,1)
sum(test[[1]])+sum(test[[2]])+sum(test[[3]])



id <- runif(1,0,1)
inc <- 50000+1:10000*5
z1 <- para_summary((tt[[1]][inc,]),4,4,1)
write.csv(z1,paste("mcmc_summary_",id,".csv",sep=""))

z2 <- para_summary((tt[[2]][inc,]),4,4,1)
write.csv(z2,paste("mcmc_summary2_",id,".csv",sep=""))

z3 <- para_summary((tt[[3]][inc,]),4,4,1)

write.csv((tt[[1]][inc,]),paste("mcmc_result_",id,".csv",sep=""))
write.csv((tt[[2]][inc,]),paste("mcmc_result2_",id,".csv",sep=""))

 save.image(paste("image_",id,".Rdata",sep=""))
#}

 load(paste("image_",id,".Rdata",sep=""))
# model adequency checking
# six season, both asym and asym
 
 mcmcresult <- read.csv(paste("mcmc_result_",id,".csv",sep=""))
 mcmcresult <- mcmcresult[,-1]
 
 mcmcresult2 <- read.csv(paste("mcmc_result2_",id,".csv",sep=""))
 mcmcresult2 <- mcmcresult2[,-1]
 sourceCpp("transmission.cpp")
 # compute the observed
 
 t <- pred_obs(data,sym,ILI,as.matrix(mcmcresult),as.matrix(mcmcresult2),c(1,1,1),0.6)
 
 save(t, file = paste("prediction_",id,".Rdata",sep=""))
 
 load(paste("prediction_",id,".Rdata",sep=""))
 
 outtable1 <- cbind(t[[1]][,1],para_summary(t(t[[1]][,-1]),4,3,0)[,-4])
 outtable2 <- cbind(t[[2]][,1],para_summary(t(t[[2]][,-1]),4,3,0)[,-4])
 outtable3 <- cbind(t[[3]][,1],para_summary(t(t[[3]][,-1]),4,3,0)[,-4])
 
 out1 <- cbind(outtable1[1:63,],outtable1[1:63+63,],outtable1[1:63+63*2,],outtable1[1:63+63*3,],outtable1[1:63+63*4,],outtable1[1:63+63*5,])
 write.csv(out1,paste("model_fit1_",id,".csv",sep=""))
 # 2 symptomatic, 3, asymptoamtic
 out2 <- cbind(outtable2,outtable3)
 out2 <- out2[-c(0:7*9+1),]
 write.csv(out2,paste("model_fit2_",id,".csv",sep=""))
 
 
 #### simulation to compute the proportion of attribution
 sourceCpp("transmission.cpp")
 
 mcmcresult <- read.csv(paste("mcmc_result_",id,".csv",sep=""))
 mcmcresult <- mcmcresult[,-1]
 
 mcmcresult2 <- read.csv(paste("mcmc_result2_",id,".csv",sep=""))
 mcmcresult2 <- mcmcresult2[,-1]
 # full
 uu21list <- matrix(NA,20,nrow(mcmcresult))
 # no hh
 uu22list <- matrix(NA,20,nrow(mcmcresult))
 # no asym
 uu23list <- matrix(NA,20,nrow(mcmcresult))
 
 for (i in 1:20){
   uu21 <- pred_obs(data,sym,ILI,as.matrix(mcmcresult),as.matrix(mcmcresult2),c(1,1,1),0.6)
   para_nohh <- as.matrix(mcmcresult)
   para_nohh[,12:17] <- 0
   uu22 <- pred_obs(data,sym,ILI,para_nohh,as.matrix(mcmcresult2),c(1,1,1),0.6)
   para_nohh2 <- as.matrix(mcmcresult)
   para_nohh2[,30] <- -20
   uu23 <- pred_obs(data,sym,ILI,para_nohh2,as.matrix(mcmcresult2),c(1,1,1),0.6)
   uu21list[i,] <- colSums(uu21[[4]])[-1]
   uu22list[i,] <- colSums(uu22[[4]])[-1]
   uu23list[i,] <- colSums(uu23[[4]])[-1]
 }
 
rec1 <- (colMeans( uu21list) - colMeans( uu22list)) / colMeans( uu21list)
rec2 <- (colMeans( uu23list) - colMeans( uu22list)) / (colMeans( uu21list) - colMeans( uu22list))

outmat <- matrix(NA,7,3)

outmat[1,1] <- mean(rec1)
outmat[1,2:3] <- quantile(rec1,c(0.025,0.975))
outmat[2,1] <- mean(rec2)
outmat[2,2:3] <- quantile(rec2,c(0.025,0.975))
outmat 

write.csv(outmat,paste("pp_att_",id,".csv",sep=""))
